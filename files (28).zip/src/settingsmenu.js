export class SettingsMenu {
  constructor(game) {
    this.game = game;
    this.root = game.root;
    this.menu = document.createElement('div');
    this.menu.className = 'settings-menu';
    this.menu.innerHTML = `
      <h2>Settings</h2>
      <label>Sound Volume <input type="range" min="0" max="100" value="50" /></label>
      <br />
      <label>Edit Controls (stub)</label>
      <br />
      <button id="settings-close-btn">Close</button>
    `;
    this.root.appendChild(this.menu);

    this.menu.querySelector('#settings-close-btn').onclick = () => this.game.closeSettings();

    this.hide();
  }

  show() { this.menu.style.display = 'block'; }
  hide() { this.menu.style.display = 'none'; }
}