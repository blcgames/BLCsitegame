export class PauseMenu {
  constructor(game) {
    this.game = game;
    this.root = game.root;
    this.menu = document.createElement('div');
    this.menu.className = 'pause-menu';
    this.menu.innerHTML = `
      <h2>Paused</h2>
      <button id="resume-btn">Resume</button>
      <button id="save-btn">Save Game</button>
      <button id="settings-btn">Settings</button>
    `;
    this.root.appendChild(this.menu);

    this.menu.querySelector('#resume-btn').onclick = () => this.game.resume();
    this.menu.querySelector('#save-btn').onclick = () => alert('Game saved! (stub)');
    this.menu.querySelector('#settings-btn').onclick = () => this.game.openSettings();

    this.hide();
  }

  show() { this.menu.style.display = 'block'; }
  hide() { this.menu.style.display = 'none'; }
}