export class Inventory {
  constructor(game) {
    this.game = game;
    this.items = [];
    this.hotbar = [null, null, null, null, null, null, null, null, null, null];
    this.selectedHotbar = 0;

    this.inventoryDiv = document.createElement('div');
    this.inventoryDiv.className = 'inventory';
    this.root = game.root;
    this.root.appendChild(this.inventoryDiv);

    this.hotbarDiv = document.createElement('div');
    this.hotbarDiv.className = 'hotbar';
    this.root.appendChild(this.hotbarDiv);

    this.renderHotbar();
    this.setupListeners();
  }

  show() {
    this.renderHotbar();
  }

  toggle() {
    if (this.inventoryDiv.classList.contains('open')) {
      this.inventoryDiv.classList.remove('open');
    } else {
      this.inventoryDiv.classList.add('open');
      this.renderInventory();
    }
  }

  setupListeners() {
    window.addEventListener('keydown', e => {
      if (e.key >= '1' && e.key <= '9') {
        this.selectedHotbar = parseInt(e.key) - 1;
        this.renderHotbar();
      }
      if (e.key === 'g' || e.key === 'G') {
        // Drop selected item
        this.dropSelected();
      }
    });
  }

  renderHotbar() {
    this.hotbarDiv.innerHTML = '';
    this.hotbar.forEach((item, i) => {
      const slot = document.createElement('div');
      slot.className = 'hotbar-slot' + (i === this.selectedHotbar ? ' selected' : '');
      slot.textContent = item ? item.name : '';
      this.hotbarDiv.appendChild(slot);
    });
  }

  renderInventory() {
    this.inventoryDiv.innerHTML = '';
    this.items.forEach(item => {
      const div = document.createElement('div');
      div.className = 'hotbar-slot';
      div.textContent = item.name;
      this.inventoryDiv.appendChild(div);
    });
  }

  dropSelected() {
    const item = this.hotbar[this.selectedHotbar];
    if (item) {
      // TODO: Drop item into world
      this.hotbar[this.selectedHotbar] = null;
      this.renderHotbar();
    }
  }
}