// Entry point for your game. Import your modules and start the game here.

import { Game } from './game.js';

window.addEventListener('DOMContentLoaded', () => {
  // Set up the game in #game-root
  const root = document.getElementById('game-root');
  const game = new Game(root);
  game.start();
});