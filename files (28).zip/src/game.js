import { Menu } from './menu.js';
import { World } from './world.js';
import { Player } from './player.js';
import { Inventory } from './inventory.js';
import { PauseMenu } from './pausemenu.js';
import { SettingsMenu } from './settingsmenu.js';

export class Game {
  constructor(root) {
    this.root = root;
    this.menu = new Menu(this);
    this.world = null;
    this.player = null;
    this.inventory = null;
    this.pauseMenu = new PauseMenu(this);
    this.settingsMenu = new SettingsMenu(this);

    this.state = 'menu'; // 'menu', 'playing', 'paused', 'settings'
  }

  init() {
    this.menu.show();
    this.setupGlobalListeners();
  }

  startNewGame() {
    this.menu.hide();
    this.world = new World(this);
    this.player = new Player(this);
    this.inventory = new Inventory(this);
    this.state = 'playing';
    this.world.start();
    this.player.start();
    this.inventory.show();
  }

  loadGame() {
    // TODO: Load game state from localStorage or file
    this.startNewGame();
  }

  pause() {
    if (this.state === 'playing') {
      this.state = 'paused';
      this.pauseMenu.show();
      this.world.pause();
    }
  }

  resume() {
    if (this.state === 'paused') {
      this.state = 'playing';
      this.pauseMenu.hide();
      this.world.resume();
    }
  }

  openSettings() {
    this.settingsMenu.show();
  }

  closeSettings() {
    this.settingsMenu.hide();
  }

  setupGlobalListeners() {
    window.addEventListener('keydown', e => {
      if (e.key === 'p' || e.key === 'P') {
        if (this.state === 'playing') this.pause();
        else if (this.state === 'paused') this.resume();
      }
      if (e.key === 'Tab') {
        e.preventDefault();
        if (this.inventory) this.inventory.toggle();
      }
    });
  }
}