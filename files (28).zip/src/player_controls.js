export class FPSControls {
  constructor(player) {
    this.player = player;
    this.enabled = false;
    // TODO: Store WASD, shift, ctrl, space key states and hook up mouse look for FPS
  }

  enable() {
    if (this.enabled) return;
    this.enabled = true;
    window.addEventListener('keydown', this.handleKeyDown.bind(this));
    window.addEventListener('keyup', this.handleKeyUp.bind(this));
    // TODO: Mouse look etc.
  }

  handleKeyDown(e) {
    // e.key: 'w', 'a', 's', 'd', 'Shift', 'Control', ' '
    // TODO: Set movement direction, running, crouching, jumping, etc.
  }

  handleKeyUp(e) {
    // TODO: Unset movement direction, running, crouching, jumping, etc.
  }
}