import { Biome } from './biome.js';

export class World {
  constructor(game) {
    this.game = game;
    this.time = 0; // Minutes in the current day
    this.day = 1;
    this.season = 0; // 0: Spring, 1: Summer, 2: Fall, 3: Winter
    this.biomes = [];
    this.running = false;
    this.TICKS_PER_SECOND = 10;
    this.DAY_LENGTH = 24 * 60; // Minutes in a day
    this.SEASON_LENGTH = 5; // Days per season
  }

  start() {
    this.running = true;
    this.tick();
  }

  tick() {
    if (!this.running) return;
    this.time += 1;
    if (this.time >= this.DAY_LENGTH) {
      this.time = 0;
      this.day += 1;
      if (this.day > this.SEASON_LENGTH) {
        this.day = 1;
        this.season = (this.season + 1) % 4;
      }
    }
    // TODO: Update world state (day/night, temperature, biomes, etc.)
    setTimeout(() => this.tick(), 1000 / this.TICKS_PER_SECOND);
  }

  pause() { this.running = false; }
  resume() {
    if (!this.running) {
      this.running = true;
      this.tick();
    }
  }
}