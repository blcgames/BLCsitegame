export default {
  root: 'public',
  build: {
    outDir: '../dist'
  }
};