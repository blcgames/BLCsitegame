import { Game } from './src/game.js';
import { UI } from './src/ui.js';

const mainMenu = document.getElementById('mainMenu');
const pauseMenu = document.getElementById('pauseMenu');
const hud = document.getElementById('hud');

let game = null;

function showMainMenu() {
  mainMenu.style.display = '';
  pauseMenu.style.display = 'none';
  hud.style.display = 'none';
}
function hideMenus() {
  mainMenu.style.display = 'none';
  pauseMenu.style.display = 'none';
  hud.style.display = '';
}
function showPauseMenu() {
  pauseMenu.style.display = '';
  mainMenu.style.display = 'none';
  hud.style.display = 'none';
}

window.addEventListener('keydown', (e) => {
  if (e.code === 'KeyP') {
    if (pauseMenu.style.display === 'none') {
      showPauseMenu();
      game?.pause();
    } else {
      hideMenus();
      game?.resume();
    }
  }
});

document.getElementById('newGameBtn').onclick = () => {
  hideMenus();
  startGame('new');
};
document.getElementById('loadGameBtn').onclick = () => {
  hideMenus();
  startGame('load');
};
document.getElementById('resumeBtn').onclick = () => {
  hideMenus();
  game?.resume();
};
document.getElementById('saveGameBtn').onclick = () => {
  game?.saveGame();
  UI.showCenterMsg('Game saved!', 1200);
};
document.getElementById('loadGamePauseBtn').onclick = () => {
  game?.loadGame();
  UI.showCenterMsg('Game loaded!', 1200);
};
document.getElementById('mainMenuBtn').onclick = () => {
  game?.pause();
  showMainMenu();
};

function startGame(mode) {
  if (!game) {
    game = new Game(UI);
  }
  if (mode === 'new') game.newGame();
  else if (mode === 'load') game.loadGame();
  game.resume();
}

showMainMenu();