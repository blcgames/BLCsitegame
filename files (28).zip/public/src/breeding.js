export class Breeding {
  constructor(animals, world, game) {
    this.animals = animals;
    this.world = world;
    this.game = game;
    this.lastBreed = 0;
  }

  init() {
    this.lastBreed = performance.now();
  }

  update(delta) {
    // Breeding every 60s, but population capped
    const now = performance.now();
    if (now - this.lastBreed > 60000) {
      this.lastBreed = now;
      this._breedAnimals();
    }
  }

  _breedAnimals() {
    const maxAnimals = this.animals.maxAnimals;
    const pop = this.animals.animals.length;
    if (pop < maxAnimals) {
      // Pick a random animal to breed
      const parent = this.animals.animals[Math.floor(Math.random() * pop)];
      if (parent) {
        this.animals.spawnAnimal(parent.mesh.userData.type);
        this.game.ui.showCenterMsg(`A new ${parent.mesh.userData.type} is born!`, 1000);
      }
    }
  }
}