export class World {
  constructor(ui, game) {
    // ...existing...
    this.placedBlocks = [];
    this.chests = []; // { x, y, z, items: [...] }
  }

  // Add/restore a chest block
  addPlacedBlock({ type, x, y, z, items }) {
    // ...existing mesh/block creation...
    if (type === "chest") {
      this.chests.push({ x, y, z, items: items || [] });
    }
    // ...existing...
  }

  // Remove all chests (e.g. on load)
  resetPlacedBlocks() {
    // ...existing code...
    this.chests = [];
  }

  // Find chest at position (within small epsilon)
  getChestAt(pos) {
    return this.chests.find(
      c => Math.abs(c.x - pos.x) < 1 && Math.abs(c.y - pos.y) < 4 && Math.abs(c.z - pos.z) < 1
    );
  }

  // For save/load
  getPlacedBlocks() {
    // For each chest, save its items
    return this.placedBlocks.map(b => {
      if (b.type === "chest") {
        const chest = this.chests.find(
          c => c.x === b.x && c.y === b.y && c.z === b.z
        );
        return { ...b, items: chest ? chest.items : [] };
      }
      return b;
    });
  }
}