// Simplex noise from https://github.com/jwagner/simplex-noise.js or use your favorite noise library.
import SimplexNoise from 'https://cdn.skypack.dev/simplex-noise@4.0.1';

export class TerrainGenerator {
  constructor(seed = 1337) {
    this.noise = new SimplexNoise(seed);
    this.chunkSize = 16; // 16x16 blocks
    this.blockScale = 2;
    this.heightScale = 8;
  }

  getChunkKey(cx, cz) {
    return `${cx},${cz}`;
  }

  getHeight(x, z) {
    // Simple height using noise
    const nx = x * 0.05, nz = z * 0.05;
    return Math.floor(this.noise.noise2D(nx, nz) * this.heightScale) + 4;
  }

  getBiome(x, z) {
    // Biomes based on coordinates
    const v = this.noise.noise2D(x * 0.01, z * 0.01);
    if (v < -0.3) return "snow";
    if (v < 0.1) return "forest";
    if (v < 0.5) return "plains";
    return "desert";
  }

  generateChunk(cx, cz) {
    const blocks = [];
    for (let lx = 0; lx < this.chunkSize; ++lx) {
      for (let lz = 0; lz < this.chunkSize; ++lz) {
        const wx = cx * this.chunkSize + lx;
        const wz = cz * this.chunkSize + lz;
        const h = this.getHeight(wx, wz);
        const biome = this.getBiome(wx, wz);
        blocks.push({ x: wx, y: h, z: wz, biome });
      }
    }
    return blocks;
  }
}