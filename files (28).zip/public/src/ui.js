export class UI {
  // ...existing...

  openChestUI(chest) {
    this.chestOpen = true;
    this.currentChest = chest;
    // Simple HTML modal for chest inventory (you can style as needed)
    const chestDiv = document.createElement('div');
    chestDiv.id = "chestInventory";
    chestDiv.style.position = "absolute";
    chestDiv.style.left = "20vw";
    chestDiv.style.top = "15vh";
    chestDiv.style.width = "60vw";
    chestDiv.style.height = "60vh";
    chestDiv.style.background = "#222";
    chestDiv.style.border = "2px solid #666";
    chestDiv.style.zIndex = 9000;
    chestDiv.style.padding = "12px";
    chestDiv.innerHTML = `
      <h3 style="color:#ffd700;">Chest Inventory</h3>
      <div id="chestItems"></div>
      <button id="closeChestBtn">Close (Esc)</button>
      <div><small>Click items to transfer between chest & player</small></div>
      <div id="playerChestItems"></div>
    `;
    document.body.appendChild(chestDiv);

    this._renderChestContents();

    document.getElementById('closeChestBtn').onclick = () => this.closeChestUI();
    document.addEventListener('keydown', this._chestEscListener = (e) => {
      if (e.code === "Escape") this.closeChestUI();
    });
  }

  _renderChestContents() {
    // Render chest items
    const chest = this.currentChest;
    const inv = this.game.inventory;
    const chestDiv = document.getElementById('chestItems');
    chestDiv.innerHTML = "Chest: " + chest.items.map((item, i) =>
      item ? `<button onclick="UI._transferToPlayer(${i})">${this.iconForItem(item.type)} x${item.count}</button>` : ""
    ).join(" ");
    // Render player items
    const playerDiv = document.getElementById('playerChestItems');
    playerDiv.innerHTML = "Player: " + inv.items.map((item, i) =>
      item ? `<button onclick="UI._transferToChest(${i})">${this.iconForItem(item.type)} x${item.count}</button>` : ""
    ).join(" ");
    // Make transfer functions globally accessible for onclick
    window.UI = this;
  }

  static _transferToPlayer(index) {
    const ui = window.UI;
    const chest = ui.currentChest;
    const inv = ui.game.inventory;
    if (chest.items[index]) {
      inv.addItem(chest.items[index].type, 1);
      chest.items[index].count -= 1;
      if (chest.items[index].count <= 0) chest.items[index] = null;
      ui._renderChestContents();
    }
  }

  static _transferToChest(index) {
    const ui = window.UI;
    const chest = ui.currentChest;
    const inv = ui.game.inventory;
    if (inv.items[index]) {
      // Find first empty or same-type slot in chest
      let slot = chest.items.findIndex(it => it && it.type === inv.items[index].type);
      if (slot === -1) slot = chest.items.findIndex(it => !it);
      if (slot === -1) chest.items.push({ type: inv.items[index].type, count: 0 });
      if (slot === -1) return; // Chest full
      if (!chest.items[slot]) chest.items[slot] = { type: inv.items[index].type, count: 0 };
      chest.items[slot].count += 1;
      inv.removeItem(inv.items[index].type, 1);
      ui._renderChestContents();
    }
  }

  closeChestUI() {
    this.chestOpen = false;
    this.currentChest = null;
    document.getElementById('chestInventory').remove();
    document.removeEventListener('keydown', this._chestEscListener);
  }

  // ...rest unchanged...
}