this.recipes.push(
  {
    name: "Hoe",
    requires: { wood: 2, stone: 2 },
    output: { type: "hoe", count: 1 }
  },
  {
    name: "Wheat Seed",
    requires: { wheat: 1 },
    output: { type: "wheat_seed", count: 2 }
  },
  {
    name: "Carrot Seed",
    requires: { carrot: 1 },
    output: { type: "carrot_seed", count: 2 }
  }
  // Add more as desired
);