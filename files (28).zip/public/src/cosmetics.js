export class CosmeticsUI {
  constructor(game, ui) {
    this.game = game;
    this.ui = ui;
  }

  show() {
    let html = "<div style='background:#222;padding:20px;color:#fff;max-width:400px;'>";
    html += `<h2>Cosmetics</h2><ul>`;
    const cosmeticList = [
      { key: "builder_hat", name: "Builder's Hat", emoji: "🎩" },
      { key: "explorer_cloak", name: "Explorer's Cloak", emoji: "🧥" }
      // Add more
    ];
    for (const c of cosmeticList) {
      const unlocked = this.game.cosmetics && this.game.cosmetics[c.key];
      html += `<li>
        <button ${unlocked ? "" : "disabled"} onclick="window.cosmeticsUI.select('${c.key}')">
          ${c.emoji} ${c.name} ${unlocked ? "" : "🔒"}
        </button></li>`;
    }
    html += "</ul><button onclick='window.cosmeticsUI.hide()'>Close</button></div>";
    const div = document.createElement("div");
    div.id = "cosmeticsPanel";
    div.style.position = "absolute";
    div.style.top = "10vh";
    div.style.left = "50%";
    div.style.transform = "translateX(-50%)";
    div.style.zIndex = 5000;
    div.innerHTML = html;
    document.body.appendChild(div);
    window.cosmeticsUI = this;
  }

  select(key) {
    this.game.selectedCosmetic = key;
    this.ui.showCenterMsg("Cosmetic equipped!", 1000);
    this.hide();
    // You can add code to change character model/skin here!
  }

  hide() {
    const div = document.getElementById("cosmeticsPanel");
    if (div) div.remove();
  }
}