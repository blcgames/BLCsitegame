saveGame() {
  // ...existing...
  animals: this.animals.animals.map(a => ({
    type: a.mesh.userData.type,
    x: a.mesh.position.x,
    y: a.mesh.position.y,
    z: a.mesh.position.z,
    tamed: !!a.tamed,
    ownerId: a.ownerId || null
  })),
  // ...existing...
}
loadGame() {
  // ...existing...
  for (const animal of save.animals || []) {
    this.animals.spawnAnimal(animal.type, animal.x, animal.y, animal.z, animal.tamed, animal.ownerId);
    // Optionally set tamed color here as well
  }
  // ...existing...
}