unlock(key) {
  const a = this.achievements.find(a => a.key === key);
  if (a && !a.unlocked) {
    a.unlocked = true;
    this.ui.showCenterMsg(`Achievement unlocked: ${a.name}!`, 2000);
    this.grantReward(a.reward);
    this.save();
  }
}

grantReward(reward) {
  if (!reward) return;
  // Unlock recipe
  if (reward.recipe) {
    this.game.crafting.unlockRecipe(reward.recipe);
    this.ui.showCenterMsg(`New recipe unlocked: ${reward.recipe.replace("_", " ")}!`, 1800);
  }
  // Unlock cosmetic
  if (reward.cosmetic) {
    if (!this.game.cosmetics) this.game.cosmetics = {};
    this.game.cosmetics[reward.cosmetic] = true;
    this.ui.showCenterMsg(`New cosmetic unlocked!`, 1800);
  }
}