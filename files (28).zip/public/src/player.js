tryCollectResource() {
  const pos = this.controls.getObject().position;
  const node = this.world.getNearbyResource(pos);
  if (node) {
    // Tool requirement logic
    let requiredTool = null;
    if (node.userData.type === "wood") requiredTool = "axe";
    if (node.userData.type === "stone") requiredTool = "pickaxe";
    if (node.userData.type === "berry") requiredTool = null;
    if (node.userData.type === "water") requiredTool = null;
    // Add more types as needed

    const slot = this.game.inventory.hotbar[this.game.inventory.selectedHotbar];
    const hasTool = requiredTool === null || (slot && slot.type === requiredTool);

    if (!hasTool) {
      this.ui.showCenterMsg(`You need a ${requiredTool} to collect this!`, 1200);
      return;
    }

    // (Optional) Tool durability: decrease here

    // Add to inventory
    this.game.inventory.addItem(node.userData.type, 1);
    this.ui.showCenterMsg(`Collected ${node.userData.type}`);
    this.world.removeResource(node);
  } else {
    this.ui.showCenterMsg('No resource nearby');
  }
}