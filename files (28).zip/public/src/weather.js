export class Weather {
  constructor(world) {
    this.world = world;
    this.state = "Clear";
    this.states = ["Clear", "Rain", "Snow", "Storm"];
    this.effects = {
      "Clear": { temp: 0, waterBonus: 0 },
      "Rain": { temp: -2, waterBonus: 10 },
      "Snow": { temp: -10, waterBonus: 0 },
      "Storm": { temp: -5, waterBonus: 6 }
    };
    this.dayCounter = 0;
    this.changeWeather();
  }

  reset() {
    this.state = "Clear";
    this.dayCounter = 0;
    this.changeWeather();
  }

  update() {
    // Weather changes every in-game day
    this.dayCounter++;
    if (this.dayCounter >= 1) { // Change weather daily
      this.changeWeather();
      this.dayCounter = 0;
    }
  }

  changeWeather() {
    // Random, but weighted by season
    const season = this.world.season;
    let pool = ["Clear", "Clear", "Rain"];
    if (season === "Winter") pool = ["Snow", "Clear", "Clear", "Storm"];
    if (season === "Autumn") pool = ["Rain", "Rain", "Clear", "Storm"];
    if (season === "Summer") pool = ["Clear", "Clear", "Clear", "Storm"];
    this.state = pool[Math.floor(Math.random() * pool.length)];
  }

  getEffect() {
    return this.effects[this.state] || this.effects["Clear"];
  }
}