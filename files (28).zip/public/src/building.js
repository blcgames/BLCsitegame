showGhostBlock() {
  if (this.ghostBlock) return;
  const type = this.selectedBlockType();
  if (!type) return;

  let geometry, material;
  if (type === "door") {
    geometry = new THREE.BoxGeometry(2, 6, 0.5);
    material = new THREE.MeshStandardMaterial({ color: 0xdeb887, transparent: true, opacity: 0.5 });
  } else if (type === "workbench") {
    geometry = new THREE.BoxGeometry(4, 2, 2);
    material = new THREE.MeshStandardMaterial({ color: 0x996633, transparent: true, opacity: 0.5 });
  } else if (type === "chest") {
    geometry = new THREE.BoxGeometry(2, 2, 2);
    material = new THREE.MeshStandardMaterial({ color: 0xffd700, transparent: true, opacity: 0.5 });
  } else {
    geometry = new THREE.BoxGeometry(2,2,2);
    material = new THREE.MeshStandardMaterial({ color: type === "wood" ? 0x8b5a2b : 0x888888, transparent: true, opacity: 0.5 });
  }
  this.ghostBlock = new THREE.Mesh(geometry, material);
  this.ghostBlock.position.copy(this.getBuildPosition());
  this.world.scene.add(this.ghostBlock);
}

tryPlaceBlock() {
  const type = this.selectedBlockType();
  if (!type) {
    this.ui.showCenterMsg("Select a buildable item in hotbar.", 1200);
    return;
  }

  // Remove one item from inventory
  if (!this.inventory.removeItem(type, 1)) {
    this.ui.showCenterMsg("No items left!", 1200);
    return;
  }

  let geometry, material;
  if (type === "door") {
    geometry = new THREE.BoxGeometry(2, 6, 0.5);
    material = new THREE.MeshStandardMaterial({ color: 0xdeb887 });
  } else if (type === "workbench") {
    geometry = new THREE.BoxGeometry(4, 2, 2);
    material = new THREE.MeshStandardMaterial({ color: 0x996633 });
  } else if (type === "chest") {
    geometry = new THREE.BoxGeometry(2, 2, 2);
    material = new THREE.MeshStandardMaterial({ color: 0xffd700 });
  } else {
    geometry = new THREE.BoxGeometry(2,2,2);
    material = new THREE.MeshStandardMaterial({ color: type === "wood" ? 0x8b5a2b : 0x888888 });
  }
  const block = new THREE.Mesh(geometry, material);
  block.position.copy(this.getBuildPosition());
  block.userData = { type };
  this.world.scene.add(block);
  this.world.recordPlacedBlock(type, block.position);
  this.ui.showCenterMsg(`Placed ${type}!`, 900);

  this.hideGhostBlock();
  this.showGhostBlock();
}