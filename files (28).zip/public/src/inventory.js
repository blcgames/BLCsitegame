export class Inventory {
  constructor(ui, player, game) {
    this.ui = ui;
    this.player = player;
    this.game = game;
    this.size = 18;
    this.items = new Array(this.size).fill(null);
    this.hotbarSize = 6;
    this.hotbar = new Array(this.hotbarSize).fill(null);
    this.selectedHotbar = 0;
    this.inventoryOpen = false;
    this._initListeners();
  }

  init() {
    // Example starting items
    this.items[0] = { type: "wood", count: 12 };
    this.items[1] = { type: "stone", count: 6 };
    this._updateHotbar();
    this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water);
  }

  _initListeners() {
    document.addEventListener('keydown', (e) => {
      if (e.code === 'Tab') {
        e.preventDefault();
        this.toggleInventory();
      }
      if (e.code === 'KeyG' && !this.inventoryOpen) {
        this.dropSelected();
      }
      for (let i = 1; i <= this.hotbarSize; ++i) {
        if (e.code === `Digit${i}` && !this.inventoryOpen) {
          this.selectedHotbar = i - 1;
          this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water);
        }
      }
    });
  }

  toggleInventory() {
    this.inventoryOpen = !this.inventoryOpen;
    document.getElementById('inventory').style.display = this.inventoryOpen ? "" : "none";
    this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water, this);
  }

  // Update hotbar from first 6 slots of main inventory
  _updateHotbar() {
    for (let i = 0; i < this.hotbarSize; ++i) {
      this.hotbar[i] = this.items[i] ? { ...this.items[i] } : null;
    }
    this.player.hotbar = this.hotbar;
    this.player.activeHotbar = this.selectedHotbar;
  }

  addItem(type, count = 1) {
    // Try to stack or add to empty
    for (let i = 0; i < this.size; ++i) {
      if (this.items[i] && this.items[i].type === type) {
        this.items[i].count += count;
        this._updateHotbar();
        this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water, this);
        return true;
      }
    }
    for (let i = 0; i < this.size; ++i) {
      if (!this.items[i]) {
        this.items[i] = { type, count };
        this._updateHotbar();
        this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water, this);
        return true;
      }
    }
    return false; // Inventory full
  }

  removeItem(type, count = 1) {
    for (let i = 0; i < this.size; ++i) {
      if (this.items[i] && this.items[i].type === type) {
        if (this.items[i].count > count) {
          this.items[i].count -= count;
        } else {
          this.items[i] = null;
        }
        this._updateHotbar();
        this.ui.updateHUD(this.player, this.game.world, this.game.food, this.game.water, this);
        return true;
      }
    }
    return false;
  }

  dropSelected() {
    const slot = this.selectedHotbar;
    const item = this.hotbar[slot];
    if (!item) return;
    this.removeItem(item.type, 1);
    // TODO: actually spawn item in the world for pickup
    this.ui.showCenterMsg(`Dropped 1 ${item.type}`);
  }
}