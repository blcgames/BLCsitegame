export class Migration {
  constructor(animals, world, game) {
    this.animals = animals;
    this.world = world;
    this.game = game;
    this.lastMigration = 0;
  }

  init() {
    this.lastMigration = performance.now();
  }

  update(delta) {
    // Migrate every in-game "day" (simulate: every 40s)
    const now = performance.now();
    if (now - this.lastMigration > 40000) {
      this.lastMigration = now;
      this._migrateAnimals();
    }
  }

  _migrateAnimals() {
    const currentSeason = this.world.season;
    for (const animal of this.animals.animals) {
      // Move some animals farther away based on season
      let dx = 0, dz = 0;
      if (animal.mesh.userData.type === "deer") {
        // Deer prefer forests in summer, open in winter
        if (currentSeason === "Winter") dz = 10 + Math.random() * 20;
        if (currentSeason === "Summer") dx = -10 - Math.random() * 20;
      }
      if (animal.mesh.userData.type === "rabbit") {
        // Rabbits move toward edges in autumn
        if (currentSeason === "Autumn") dx = 15 + Math.random() * 10;
      }
      animal.mesh.position.x += dx;
      animal.mesh.position.z += dz;
    }
    this.game.ui.showCenterMsg("Animal herds are migrating...", 1500);
  }
}