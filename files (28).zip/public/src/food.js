export class Food {
  constructor(player, game) {
    this.player = player;
    this.game = game;
    this.food = 100;
    this.lastTick = performance.now();
  }
  init() { this.food = 100; }
  update(delta) {
    // Decrease food over time
    this.food -= delta * 2; // 2 units per second
    if (this.food < 0) this.food = 0;
    // If player "dies" from hunger
    if (this.food === 0) {
      this.game.ui.showCenterMsg("You starved! Food reset.", 1800);
      this.food = 100;
    }
  }
  eat() {
    // Try to eat "berry" or "meat" from inventory
    if (this.game.inventory.removeItem("berry", 1)) {
      this.food = Math.min(this.food + 22, 100);
      this.game.ui.showCenterMsg("You ate a berry!", 800);
    } else if (this.game.inventory.removeItem("meat", 1)) {
      this.food = Math.min(this.food + 38, 100);
      this.game.ui.showCenterMsg("You ate meat!", 800);
    } else {
      this.game.ui.showCenterMsg("No food in inventory!", 800);
    }
  }
}