export class Water {
  constructor(player, game) {
    this.player = player;
    this.game = game;
    this.water = 100;
    this.lastTick = performance.now();
  }
  init() { this.water = 100; }
  update(delta) {
    // Decrease water over time
    this.water -= delta * 3; // 3 units per second
    if (this.water < 0) this.water = 0;
    // If player "dies" from thirst
    if (this.water === 0) {
      this.game.ui.showCenterMsg("You died of thirst! Water reset.", 1800);
      this.water = 100;
    }
  }
  drink() {
    // Try to drink "berry" (berries hydrate a little) or "water" from inventory
    if (this.game.inventory.removeItem("water", 1)) {
      this.water = Math.min(this.water + 32, 100);
      this.game.ui.showCenterMsg("You drank water!", 800);
    } else if (this.game.inventory.removeItem("berry", 1)) {
      this.water = Math.min(this.water + 8, 100);
      this.game.ui.showCenterMsg("You ate a berry (some hydration)!", 800);
    } else {
      this.game.ui.showCenterMsg("No water in inventory!", 800);
    }
  }
}