export class Temperature {
  constructor(world) {
    this.world = world;
    this.value = 20;
    this.baseBySeason = {
      "Spring": 14,
      "Summer": 26,
      "Autumn": 12,
      "Winter": -5
    };
    this.dayCounter = 0;
  }

  reset() {
    this.value = 20;
    this.dayCounter = 0;
  }

  update() {
    // Called once per in-game day
    this.dayCounter++;
    if (this.dayCounter >= 1) {
      this._calcTemperature();
      this.dayCounter = 0;
    }
  }

  _calcTemperature() {
    const base = this.baseBySeason[this.world.season] || 10;
    const weatherEffect = this.world.weather.getEffect().temp;
    // Add some random daily fluctuation
    this.value = base + weatherEffect + (Math.random() * 8 - 4);
  }
}