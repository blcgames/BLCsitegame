import * as THREE from 'https://unpkg.com/three@0.153.0/build/three.module.js';

export class Biomes {
  constructor(world) {
    this.world = world;
    // All biome data, tree/rock/animal spawn logic, etc
  }
  generateProceduralTerrain(size=64) {
    // Returns a THREE.Mesh with vertex colors for biomes
    // (Use your previous procedural terrain logic here)
    const geo = new THREE.PlaneGeometry(size, size, size, size);
    geo.rotateX(-Math.PI/2);
    for(let i=0; i<geo.attributes.position.count; ++i) {
      let x = geo.attributes.position.getX(i), z = geo.attributes.position.getZ(i);
      let y = 10 * Math.sin(x/14) * Math.cos(z/14)
            + 4 * Math.sin(x/4) * Math.cos(z/7)
            + 2 * Math.cos(z/3) * Math.sin(x/9);
      geo.attributes.position.setY(i, y);
    }
    geo.computeVertexNormals();
    let colors = [];
    for(let i=0; i<geo.attributes.position.count; ++i) {
      let y = geo.attributes.position.getY(i);
      let c = new THREE.Color(0x88bb77); // TODO: color by biome
      colors.push(c.r, c.g, c.b);
    }
    geo.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    const mat = new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true });
    return new THREE.Mesh(geo, mat);
  }
}