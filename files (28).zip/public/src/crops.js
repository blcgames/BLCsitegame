// Add to growthTimes
this.growthTimes = {
  wheat: 40,
  carrot: 50,
  berry: 35,
  potato: 50,
  pumpkin: 80,
  melon: 80,
  golden_wheat: 100,
  magic_berry: 120
};
this.stages = 3; // Can increase for more visual detail

// Update _createCropMesh for new types
if (type === 'potato') {
  // Similar to carrot but brown
} else if (type === 'pumpkin') {
  // Use a small orange cube or sphere for immature, a large one for mature
} else if (type === 'melon') {
  // Use a green cube or sphere
} else if (type === 'golden_wheat') {
  // Like wheat but golden and perhaps glowing (emissive material)
} else if (type === 'magic_berry') {
  // Like berry but purple or glowing
}