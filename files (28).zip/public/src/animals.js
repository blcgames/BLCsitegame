export class Animals {
  // ...existing...
  animals = []; // Each animal: { mesh, target, speed, tamed, ownerId }
  
  // Update animal spawn to allow tamed flag
  spawnAnimal(type, x, y, z, tamed = false, ownerId = null) {
    // ...existing mesh setup...
    const animalObj = { mesh, target: null, speed: 1.0, tamed, ownerId };
    this.world.scene.add(mesh);
    this.animals.push(animalObj);
  }

  // Save/load: include tamed, ownerId
}