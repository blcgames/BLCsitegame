// --- Biome Definitions ---
export const BIOMES = [
  { name: "plains",  color: 0x88bb77, minHeight: -10, maxHeight: 10, trees: ["oak"], rocks: ["stone"] },
  { name: "forest",  color: 0x228833, minHeight: 7,  maxHeight: 36, trees: ["pine","birch"], rocks: ["stone"] },
  { name: "mountain",color: 0xcccccc, minHeight: 30, maxHeight: 60, trees: [], rocks: ["stone","boulder"] },
  { name: "desert",  color: 0xffe397, minHeight: -5, maxHeight: 16, trees: ["palm"], rocks: ["cactus","rock"] },
  { name: "taiga",   color: 0x7d9a82, minHeight: 15, maxHeight: 38, trees: ["spruce"], rocks: ["stone"] },
  { name: "swamp",   color: 0x557744, minHeight: -7, maxHeight: 8, trees: ["willow"], rocks: ["rock"] },
  { name: "beach",   color: 0xfaf3a2, minHeight: -10, maxHeight: -4, trees: [], rocks: [] },
  { name: "tundra",  color: 0xc7e3e3, minHeight: 32, maxHeight: 55, trees: ["spruce"], rocks: [] },
];
export function getBiomeAtHeight(y) {
  return BIOMES.find(b => y >= b.minHeight && y < b.maxHeight) || BIOMES[0];
}

// --- Example: Spawning Biome Objects on Terrain ---
export function spawnBiomes(scene, terrain) {
  // Assume terrain is a PlaneGeometry mesh with vertex displacement for height
  const vertices = terrain.geometry.attributes.position;
  for (let i = 0; i < vertices.count; i++) {
    const x = vertices.getX(i), y = vertices.getY(i), z = vertices.getZ(i);
    const biome = getBiomeAtHeight(y);
    // Place trees/rocks based on biome
    if (Math.random() < 0.01 && biome.trees.length) {
      const tree = createSimpleTree(new THREE.Vector3(x, y, z), biome.trees[0]);
      scene.add(tree);
    }
    if (Math.random() < 0.006 && biome.rocks.length) {
      const rock = createSimpleRock(new THREE.Vector3(x, y, z), biome.rocks[0]);
      scene.add(rock);
    }
  }
}

// --- Example Simple Tree/Rock for Prototyping ---
export function createSimpleTree(position, type="oak") {
  const group = new THREE.Group();
  const trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.3, 2, 8),
    new THREE.MeshStandardMaterial({ color: 0x8b5c2d })
  );
  trunk.position.y = 1;
  group.add(trunk);
  const foliage = new THREE.Mesh(
    new THREE.SphereGeometry(0.9, 8, 8),
    new THREE.MeshStandardMaterial({ color: type==="pine"?0x335c29:0x2d7f2d })
  );
  foliage.position.y = 2.2;
  group.add(foliage);
  group.position.copy(position);
  return group;
}
export function createSimpleRock(position, type="stone") {
  const mesh = new THREE.Mesh(
    new THREE.DodecahedronGeometry(type==="boulder"?1.2:0.6, 0),
    new THREE.MeshStandardMaterial({ color: 0x888888 })
  );
  mesh.position.copy(position);
  return mesh;
}

// --- Save/Load Example (expand for full gameplay state) ---
export function getSaveData(camera) {
  return JSON.stringify({
    camera: {
      position: camera.position.toArray(),
      rotation: [camera.rotation.x, camera.rotation.y, camera.rotation.z]
    }
    // Add more: player stats, inventory, etc.
  });
}
export function setSaveData(camera, data) {
  if (!data?.camera) return;
  camera.position.fromArray(data.camera.position);
  camera.rotation.x = data.camera.rotation[0];
  camera.rotation.y = data.camera.rotation[1];
  camera.rotation.z = data.camera.rotation[2];
}