import random

def mine_rock(rock):
    drops = []
    for drop in rock.get("drops", []):
        if random.random() < drop["chance"]:
            drops.append(drop["item"])
    if not drops:
        for drop in rock.get("drops", []):
            if drop["chance"] == 1.0:
                drops.append(drop["item"])
    return drops

# Usage:
# from biomes_resources import BIOMES
# rock = BIOMES["Tundra"]["rocks"][0]
# print(mine_rock(rock))