// TemperatureSystem.js

export class TemperatureSystem {
  constructor(player, worldTimeSystem, seasonSystem, options = {}) {
    this.player = player;
    this.worldTimeSystem = worldTimeSystem;
    this.seasonSystem = seasonSystem;
    this.safeTemperature = options.safeTemperature || 0;
    this.lastTemp = 20; // For smooth transition
  }

  // Returns current temperature at the specified elevation (in meters)
  getCurrentTemperature(height = 0) {
    // Calculate time of day (0 is midnight, 12 is noon)
    const minutes = this.worldTimeSystem.time % (24 * 60);
    const hours = minutes / 60;

    // Get min/max for the current season and elevation
    const [minTemp, maxTemp] = this.seasonSystem.getCurrentSeasonTempRange(height);

    // Day/night profile (same for all seasons, can be customized)
    // 00:00-06:00: min to mid
    // 06:00-11:00: mid to max
    // 11:00-14:00: max
    // 14:00-18:00: max to mid
    // 18:00-21:00: mid to min
    // 21:00-00:00: min

    let temp;
    if (hours < 6) {
      // Night: min to mid
      temp = this._lerp(minTemp, (minTemp + maxTemp) / 2, (hours) / 6);
    } else if (hours < 11) {
      // Morning: mid to max
      temp = this._lerp((minTemp + maxTemp) / 2, maxTemp, (hours - 6) / 5);
    } else if (hours < 14) {
      // Midday: peak
      temp = maxTemp;
    } else if (hours < 18) {
      // Afternoon: max to mid
      temp = this._lerp(maxTemp, (minTemp + maxTemp) / 2, (hours - 14) / 4);
    } else if (hours < 21) {
      // Evening: mid to min
      temp = this._lerp((minTemp + maxTemp) / 2, minTemp, (hours - 18) / 3);
    } else {
      // Night: min
      temp = minTemp;
    }

    // Optionally smooth transition to avoid abrupt jumps
    this.lastTemp += (temp - this.lastTemp) * 0.1;
    return this.lastTemp;
  }

  _lerp(a, b, t) {
    return a + (b - a) * t;
  }

  update(delta) {
    // No-op, kept for possible future use (e.g., temp smoothing)
  }
}