import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { Sky } from 'three/examples/jsm/objects/Sky.js';
import { Water } from 'three/examples/jsm/objects/Water2.js';
import { spawnBiomes, getSaveData, setSaveData } from './gameSystems.js';
import { createMainMenu, createPauseMenu, removePauseMenu } from './ui.js';

let camera, scene, renderer, controls, terrain;
let paused = false;

// ---- Game Start/Reset ----
function startGame(load=false) {
  // Setup scene, camera, renderer, etc.
  scene = new THREE.Scene();
  camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 0.1, 2000);
  camera.position.set(0, 20, 40);
  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  controls = new OrbitControls(camera, renderer.domElement);

  // --- Terrain ---
  let geo = new THREE.PlaneGeometry(120, 120, 120, 120);
  geo.rotateX(-Math.PI / 2);
  // Displace vertices for heightmap (simple perlin noise, stub here)
  for (let i = 0; i < geo.attributes.position.count; i++) {
    let x = geo.attributes.position.getX(i), z = geo.attributes.position.getZ(i);
    let y = 15 * Math.sin(x/24) * Math.cos(z/19) + 8 * Math.sin(x/10) * Math.cos(z/13);
    geo.attributes.position.setY(i, y);
  }
  geo.computeVertexNormals();
  terrain = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: 0x6db97b, flatShading: true }));
  scene.add(terrain);

  // --- Sky/Sun ---
  const sky = new Sky();
  sky.scale.setScalar(1000);
  scene.add(sky);
  const sun = new THREE.Vector3();
  sun.setFromSphericalCoords(1, Math.PI/2.5, 0);
  sky.material.uniforms['sunPosition'].value.copy(sun);

  // --- Water ---
  const water = new Water(
    new THREE.PlaneGeometry(2000, 2000),
    { color: 0x55aaff, scale: 4, flowDirection: new THREE.Vector2(1,1), textureWidth: 1024, textureHeight: 1024 }
  );
  water.position.y = 0;
  water.rotation.x = - Math.PI / 2;
  scene.add(water);

  // --- Biomes and Features ---
  spawnBiomes(scene, terrain);

  // --- Lighting ---
  const hemiLight = new THREE.HemisphereLight(0xffffff, 0x444444, 1.1);
  hemiLight.position.set(0, 100, 0);
  scene.add(hemiLight);
  const dirLight = new THREE.DirectionalLight(0xffffff, 1.3);
  dirLight.position.set(30, 60, 30);
  scene.add(dirLight);

  // --- Load save data? ---
  if (load && localStorage.getItem("survivalgame-save")) {
    const data = JSON.parse(localStorage.getItem("survivalgame-save"));
    setSaveData(camera, data);
  }

  paused = false;
  animate();
}

// ---- Main Menu ----
createMainMenu(
  () => { clearScene(); startGame(false); },
  () => { clearScene(); startGame(true); }
);

// ---- Pause Menu ----
window.addEventListener('keydown', e => {
  if (e.code === "Escape" && !paused) {
    pauseGame();
  }
});
function pauseGame() {
  paused = true;
  createPauseMenu(
    () => { paused = false; removePauseMenu(); animate(); },
    () => { saveGame(); },
    () => { loadGame(); },
    () => { clearScene(); createMainMenu(
      () => { clearScene(); startGame(false); },
      () => { clearScene(); startGame(true); }); }
  );
}
function saveGame() {
  localStorage.setItem("survivalgame-save", getSaveData(camera));
  alert("Game saved!");
}
function loadGame() {
  if (localStorage.getItem("survivalgame-save")) {
    setSaveData(camera, JSON.parse(localStorage.getItem("survivalgame-save")));
    paused = false;
    removePauseMenu();
    animate();
  } else {
    alert("No save found!");
  }
}

// ---- Utility ----
function clearScene() {
  if (renderer) renderer.domElement.remove();
  let menus = document.querySelectorAll('.menu');
  menus.forEach(m=>m.remove());
}

// ---- Animation Loop ----
function animate() {
  if (paused) return;
  requestAnimationFrame(animate);
  renderer.render(scene, camera);
  controls.update();
}