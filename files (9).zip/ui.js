// ui.js - Simple game menu and pause menu system

export function createMainMenu(onNew, onLoad) {
  let menu = document.createElement('div');
  menu.id = "mainMenu";
  menu.className = "menu";
  menu.innerHTML = `
    <h1>🌎 Survival Game</h1>
    <button id="newGameBtn">New Game</button>
    <button id="loadGameBtn">Load Game</button>
  `;
  document.body.appendChild(menu);
  document.getElementById('newGameBtn').onclick = () => { menu.remove(); onNew(); };
  document.getElementById('loadGameBtn').onclick = () => { menu.remove(); onLoad(); };
}

export function createPauseMenu(onContinue, onSave, onLoad, onExit) {
  let menu = document.createElement('div');
  menu.id = "pauseMenu";
  menu.className = "menu";
  menu.innerHTML = `
    <h2>Paused</h2>
    <button id="continueBtn">Continue</button>
    <button id="saveBtn">Save</button>
    <button id="loadBtn">Load</button>
    <button id="exitBtn">Exit to Main Menu</button>
  `;
  document.body.appendChild(menu);
  document.getElementById('continueBtn').onclick = () => { menu.remove(); onContinue(); };
  document.getElementById('saveBtn').onclick = () => { onSave(); };
  document.getElementById('loadBtn').onclick = () => { onLoad(); };
  document.getElementById('exitBtn').onclick = () => { menu.remove(); onExit(); };
}
export function removePauseMenu() {
  let menu = document.getElementById('pauseMenu');
  if (menu) menu.remove();
}