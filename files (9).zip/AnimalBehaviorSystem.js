// AnimalBehaviorSystem.js

export class AnimalBehaviorSystem {
  constructor(temperatureSystem) {
    this.temperatureSystem = temperatureSystem;
    // Expanded: add wolves with different comfort zones, and more!
    this.animalComfortRanges = {
      "Snow Rabbit": { minTemp: -100, maxTemp: 8 },    // Very cold-adapted
      "Grey Wolf":   { minTemp: 8, maxTemp: 35 },      // Prefers warmer, steppe/forest
      "White Wolf":  { minTemp: -100, maxTemp: 14 },   // Prefers subarctic/tundra
      "Red Fox":     { minTemp: 0, maxTemp: 27 },      // Generalist, avoids extremes
      "Arctic Fox":  { minTemp: -100, maxTemp: 12 },   // Tundra specialist
      "Deer":        { minTemp: 7, maxTemp: 29 },      // Temperate, avoids frost/heat
      "Bear":        { minTemp: 2, maxTemp: 28 },      // Wide range, not arctic
      "Boar":        { minTemp: 9, maxTemp: 38 },      // Prefers mild to hot
      "Cow":         { minTemp: 12, maxTemp: 36 },     // Prefers mild to warm
      "Sheep":       { minTemp: 6, maxTemp: 30 },      // Hardy, avoids heat
      "Horse":       { minTemp: 9, maxTemp: 32 },      // Plains, mild to warm
      "Pig":         { minTemp: 14, maxTemp: 40 },     // Prefers warmth
      "Chicken":     { minTemp: 15, maxTemp: 36 },     // Domesticated, likes warmth
      "Goat":        { minTemp: 0, maxTemp: 34 },      // Adaptable, but not arctic
      "Rabbit":      { minTemp: 7, maxTemp: 30 },      // Wide range, avoid frost/heat
      "Duck":        { minTemp: 10, maxTemp: 32 },     // Prefers wet, mild to warm
      "Moose":       { minTemp: -10, maxTemp: 20 },    // Northern, avoids heat
      "Reindeer":    { minTemp: -100, maxTemp: 10 },   // Arctic
      // Add more animals as needed!
    };
  }

  updateAnimalBehavior(animal) {
    const comfort = this.animalComfortRanges[animal.type];
    if (!comfort) {
      animal.performNormalBehavior();
      return;
    }
    const temp = this.temperatureSystem.getCurrentTemperature(animal.position.y);
    if (temp < comfort.minTemp) {
      animal.setStatus("too cold");
      animal.moveTowardComfortZone("warmer");
    } else if (temp > comfort.maxTemp) {
      animal.setStatus("too hot");
      animal.moveTowardComfortZone("cooler");
    } else {
      animal.setStatus("normal");
      animal.performNormalBehavior();
    }
  }
}