// SeasonSystem.js

export class SeasonSystem {
  constructor(options = {}) {
    this.seasons = options.seasons || [
      {
        name: "Spring",
        startDay: 0,
        minTemp: 5,
        maxTemp: 20,
        lapseRate: 0.007 // °C per meter
      },
      {
        name: "Summer",
        startDay: 90,
        minTemp: 15,
        maxTemp: 30,
        lapseRate: 0.01 // °C per meter
      },
      {
        name: "Autumn",
        startDay: 180,
        minTemp: 10,
        maxTemp: 22,
        lapseRate: 0.008 // °C per meter
      },
      {
        name: "Winter",
        startDay: 270,
        minTemp: 0,
        maxTemp: 15,
        lapseRate: 0.005 // °C per meter
      }
    ];
    this.daysPerYear = options.daysPerYear || 360;
    this.currentDay = 0;
    this.currentSeasonIndex = 0;
  }

  update(delta, worldTimeSystem) {
    this.currentDay = Math.floor(worldTimeSystem.totalMinutesElapsed / (24 * 60));
    for (let i = this.seasons.length - 1; i >= 0; i--) {
      if (this.currentDay >= this.seasons[i].startDay) {
        this.currentSeasonIndex = i;
        break;
      }
    }
  }

  getCurrentSeason() {
    return this.seasons[this.currentSeasonIndex];
  }

  getSeasonName() {
    return this.getCurrentSeason().name;
  }

  // Returns [minTemp, maxTemp] for the current season at a given elevation (meters above sea level)
  getCurrentSeasonTempRange(height = 0) {
    const s = this.getCurrentSeason();
    return [
      s.minTemp - s.lapseRate * height,
      s.maxTemp - s.lapseRate * height
    ];
  }
}