# Season and temperature system

SEASONS = ["Spring", "Summer", "Autumn", "Winter"]

SEASON_TEMP = {
    "Spring": {"min": 5, "max": 20, "lapse_rate": 0.007},
    "Summer": {"min": 15, "max": 30, "lapse_rate": 0.01},
    "Autumn": {"min": 10, "max": 22, "lapse_rate": 0.008},
    "Winter": {"min": 0, "max": 15, "lapse_rate": 0.005}
}

def get_season(day_of_year):
    if day_of_year < 90:
        return "Spring"
    elif day_of_year < 180:
        return "Summer"
    elif day_of_year < 270:
        return "Autumn"
    else:
        return "Winter"

def get_daily_temp_range(season, height):
    base = SEASON_TEMP[season]
    min_temp = base["min"] - base["lapse_rate"] * height
    max_temp = base["max"] - base["lapse_rate"] * height
    return min_temp, max_temp

def get_current_temperature(season, height, time_of_day):
    # time_of_day: 0=midnight, 12=noon, 24=midnight
    min_temp, max_temp = get_daily_temp_range(season, height)
    if time_of_day < 6:
        temp = min_temp + (max_temp - min_temp) * (time_of_day / 12)
    elif time_of_day < 18:
        temp = max_temp - (max_temp - min_temp) * abs(12-time_of_day)/12
    else:
        temp = min_temp + (max_temp - min_temp) * ((24-time_of_day) / 12)
    return temp