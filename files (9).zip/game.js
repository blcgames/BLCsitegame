// --- Main Menu Overlay ---
const menuDiv = document.createElement("div");
menuDiv.id = "mainMenu";
menuDiv.style.position = "fixed";
menuDiv.style.top = "0"; menuDiv.style.left = "0";
menuDiv.style.width = "100vw"; menuDiv.style.height = "100vh";
menuDiv.style.background = "rgba(10,20,40,0.9)";
menuDiv.style.display = "flex";
menuDiv.style.flexDirection = "column";
menuDiv.style.alignItems = "center";
menuDiv.style.justifyContent = "center";
menuDiv.style.zIndex = 9999;
menuDiv.innerHTML = `
  <h1 style="color:#fff; font-size:3em; margin-bottom:0.5em;">Survival World</h1>
  <button id="startGameBtn" style="font-size:2em; padding:0.5em 2em; cursor:pointer; margin-bottom:2em;">Start Game</button>
  <div style="color:#ccc; font-size:1.2em; max-width:30em; text-align:center;">
    Explore a seamless open world with biomes, animals, seasons, and survival. <br>
    <small>WASD to move, Mouse to look, Space to jump, E to interact, Tab for inventory.</small>
  </div>
`;
document.body.appendChild(menuDiv);

let gameStarted = false;

// --- Season temperature table (must be defined before use) ---
const SEASON_TEMP = {
  "Spring": { min: 5, max: 20, lapse: 0.007 },
  "Summer": { min: 15, max: 30, lapse: 0.01 },
  "Autumn": { min: 10, max: 22, lapse: 0.008 },
  "Winter": { min: 0, max: 15, lapse: 0.005 }
};
const SEASONS = ["Spring", "Summer", "Autumn", "Winter"];

const BIOMES = [
  {
    name: "Alpine", color: 0xcccccc, elev: 40,
    x: [-400, -200], z: [-400, -200],
    trees: ["Pine"], rocks: ["Granite"], animals: ["Mountain Goat"], plants: ["Alpine Grass"]
  },
  {
    name: "Tundra", color: 0xe0e0e0, elev: 25,
    x: [200, 400], z: [-400, -200],
    trees: [], rocks: ["Limestone"], animals: ["Caribou"], plants: []
  },
  {
    name: "Boreal", color: 0x556b2f, elev: 16,
    x: [-400, -200], z: [200, 400],
    trees: ["Spruce", "Fir"], rocks: ["Granite"], animals: ["Wolf"], plants: ["Berry Bush"]
  },
  {
    name: "Temperate", color: 0x228b22, elev: 8,
    x: [200, 400], z: [200, 400],
    trees: ["Oak", "Maple"], rocks: ["Sandstone"], animals: ["Deer"], plants: ["Wildflower"]
  },
  {
    name: "Grassland", color: 0x9acd32, elev: 4,
    x: [-100, 100], z: [-100, 100],
    trees: ["Birch"], rocks: ["Quartzite"], animals: ["Rabbit"], plants: ["Tall Grass"]
  },
  {
    name: "Desert", color: 0xf4e285, elev: 1,
    x: [200, 400], z: [0, 200],
    trees: [], rocks: ["Sandstone"], animals: ["Lizard"], plants: ["Cactus"]
  },
  {
    name: "Rainforest", color: 0x228b22, elev: 10,
    x: [-400, -200], z: [0, 200],
    trees: ["Mahogany"], rocks: ["Granite"], animals: ["Jaguar"], plants: ["Fern"]
  },
  {
    name: "Taiga", color: 0x7bb661, elev: 14,
    x: [0, 200], z: [-400, -200],
    trees: ["Pine", "Spruce"], rocks: ["Granite"], animals: ["Moose"], plants: []
  },
];

const TREE_MODELS = {
  "Pine":      {trunk:0x7D5A3E,leaf:0x234d20},
  "Spruce":    {trunk:0x7D5A3E,leaf:0x264b29},
  "Fir":       {trunk:0x5a463e,leaf:0x183e21},
  "Oak":       {trunk:0x8b5e3c,leaf:0x3e7d34},
  "Maple":     {trunk:0xaf7440,leaf:0xa43f1b},
  "Birch":     {trunk:0xd9d4bf,leaf:0x86b049},
  "Mahogany":  {trunk:0x5a1b0a,leaf:0x1c4d2d}
};
const ANIMAL_MODELS = {
  "Mountain Goat": {color:0xececec,size:4},
  "Caribou":       {color:0x8e7b51,size:4.5},
  "Wolf":          {color:0x888888,size:3.2},
  "Deer":          {color:0xaa7a47,size:4.1},
  "Rabbit":        {color:0xf6f6f6,size:1.4},
  "Lizard":        {color:0x7be34b,size:1.2},
  "Jaguar":        {color:0x3b2d13,size:3.9},
  "Moose":         {color:0x715c40,size:5}
};

function simpleNoise(x, z) {
  return (
    Math.sin(x * 0.005) * 14 +
    Math.cos(z * 0.005) * 11 +
    Math.sin((x + z) * 0.002) * 7
  );
}

// --- Helper: get biome center and influence radius
function biomeCenter(b) {
  return {
    x: (b.x[0] + b.x[1]) / 2,
    z: (b.z[0] + b.z[1]) / 2,
    rx: Math.abs(b.x[1] - b.x[0]) / 2,
    rz: Math.abs(b.z[1] - b.z[0]) / 2
  };
}

// --- Game State
let player = {
  health: 100, hunger: 100, temperature: 36.5,
  inventory: {}, position: {x:0, y:2, z:0}
};
let season = "Spring";
let timeOfDay = 6; // 0-24, hours
let dayCount = 1;

// --- For real-time synced day/night cycle (1 hour per day) ---
let lastTime = performance.now();
const SECONDS_PER_DAY = 3600; // 1 hour per game day

// --- Three.js scene setup
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x87ceeb);
const camera = new THREE.PerspectiveCamera(75, window.innerWidth/window.innerHeight, 1, 3000);
const renderer = new THREE.WebGLRenderer({antialias:true});
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff, 0.8));
const sun = new THREE.DirectionalLight(0xffffff, 1.2);
sun.position.set(100,200,100);
scene.add(sun);

// --- Smoother terrain transitions between biomes ---
const terrainSize = 800;
const terrainSeg = 256;
const terrainGeo = new THREE.PlaneGeometry(terrainSize, terrainSize, terrainSeg, terrainSeg);
const vertices = terrainGeo.attributes.position;
const colors = new Float32Array(vertices.count * 3);

for (let i = 0; i < vertices.count; i++) {
  const wx = vertices.getX(i);
  const wz = vertices.getY(i);

  // Soft falloff: 1/(1 + dist^2)
  let weights = [], sumW = 0;
  for (const b of BIOMES) {
    const c = biomeCenter(b);
    const dx = (wx - c.x) / (c.rx + 40);
    const dz = (wz - c.z) / (c.rz + 40);
    const dist = Math.sqrt(dx * dx + dz * dz);
    const w = 1 / (1 + dist * dist); // smoother transition!
    weights.push({ b, w });
    sumW += w;
  }
  // Normalize weights, compute blended height/color
  let height = 0;
  let colorA = new THREE.Color(0, 0, 0);
  if (sumW < 0.001) sumW = 1; // avoid divide by zero
  for (const { b, w } of weights) {
    const rel = w / sumW;
    let elev = b.elev;
    if (b.name === "Alpine") elev += 20 + simpleNoise(wx, wz);
    else if (b.name === "Tundra" || b.name === "Boreal") elev += 3 + simpleNoise(wx, wz) * 0.3;
    else elev += simpleNoise(wx, wz) * 0.15;
    height += rel * elev;
    colorA.r += rel * ((b.color >> 16 & 0xff) / 255);
    colorA.g += rel * ((b.color >> 8 & 0xff) / 255);
    colorA.b += rel * ((b.color & 0xff) / 255);
  }
  // If colorA is too close to black (no biome), use grass green as fallback
  if (colorA.r + colorA.g + colorA.b < 0.1) colorA.set(0x228b22);
  vertices.setZ(i, height);
  colors[i * 3 + 0] = colorA.r;
  colors[i * 3 + 1] = colorA.g;
  colors[i * 3 + 2] = colorA.b;
}
terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
terrainGeo.computeVertexNormals();

const terrainMat = new THREE.MeshPhongMaterial({ vertexColors: true, side: THREE.DoubleSide, flatShading: true });
const terrainMesh = new THREE.Mesh(terrainGeo, terrainMat);
terrainMesh.rotation.x = -Math.PI / 2;
scene.add(terrainMesh);

// --- Helper: get terrain elevation at (x, z) ---
function getTerrainHeight(x, z) {
  const half = terrainSize / 2;
  const fx = ((x + half) / terrainSize) * terrainSeg;
  const fz = ((z + half) / terrainSize) * terrainSeg;
  const ix = Math.floor(fx);
  const iz = Math.floor(fz);
  const idx = iz * (terrainSeg + 1) + ix;
  if (
    ix >= 0 && ix < terrainSeg &&
    iz >= 0 && iz < terrainSeg &&
    terrainGeo.attributes.position
  ) {
    return terrainGeo.attributes.position.getZ(idx);
  }
  return 0;
}

// --- Biome lookup at (x, z) with blend ---
function getBiomeAt(x, z) {
  let maxW = 0, mainBiome = BIOMES[0];
  for (const b of BIOMES) {
    const c = biomeCenter(b);
    const dx = (x - c.x) / (c.rx + 40);
    const dz = (z - c.z) / (c.rz + 40);
    const dist = Math.sqrt(dx * dx + dz * dz);
    const w = 1 / (1 + dist * dist);
    if (w > maxW) { maxW = w; mainBiome = b; }
  }
  return mainBiome;
}

// --- Place trees, rocks, and animals in the world on terrain ---
const trees = [], rocks = [], animals = [];
function placeOnTerrain(x, z, yOffset = 0) {
  const y = getTerrainHeight(x, z) + yOffset;
  return { x, y, z };
}
for (const b of BIOMES) {
  // Trees
  for (let i = 0; i < b.trees.length; i++) {
    for (let t = 0; t < 7; t++) {
      let tx = Math.random() * (b.x[1] - b.x[0]) + b.x[0];
      let tz = Math.random() * (b.z[1] - b.z[0]) + b.z[0];
      let { x, y, z } = placeOnTerrain(tx, tz, 0);
      let tree = makeTree(b.trees[i], x, y, z);
      scene.add(tree); trees.push({ mesh: tree, name: b.trees[i] });
    }
  }
  // Rocks
  for (let i = 0; i < b.rocks.length; i++) {
    for (let r = 0; r < 6; r++) {
      let rx = Math.random() * (b.x[1] - b.x[0]) + b.x[0];
      let rz = Math.random() * (b.z[1] - b.z[0]) + b.z[0];
      let { x, y, z } = placeOnTerrain(rx, rz, 0);
      let rock = makeRock(b.rocks[i], x, y, z);
      scene.add(rock); rocks.push({ mesh: rock, name: b.rocks[i] });
    }
  }
  // Animals
  for (let i = 0; i < b.animals.length; i++) {
    for (let a = 0; a < 3; a++) {
      let ax = Math.random() * (b.x[1] - b.x[0]) + b.x[0];
      let az = Math.random() * (b.z[1] - b.z[0]) + b.z[0];
      let { x, y, z } = placeOnTerrain(ax, az, 2);
      let animal = makeAnimal(b.animals[i], x, y, z);
      scene.add(animal.mesh);
      animals.push(animal);
    }
  }
}

// --- Models ---
function makeTree(name, x, y, z) {
  let def = TREE_MODELS[name] || { trunk: 0x7D5A3E, leaf: 0x3A5230 };
  let group = new THREE.Group();
  let trunk = new THREE.Mesh(
    new THREE.CylinderGeometry(0.7, 1.1, 7, 8),
    new THREE.MeshPhongMaterial({ color: def.trunk })
  );
  trunk.position.set(x, y + 3.5, z);
  group.add(trunk);
  let leaves = new THREE.Mesh(
    new THREE.SphereGeometry(3, 10, 8),
    new THREE.MeshPhongMaterial({ color: def.leaf })
  );
  leaves.position.set(x, y + 7.8, z);
  group.add(leaves);
  group.position.set(x, 0, z);
  return group;
}
function makeRock(name, x, y, z) {
  let col = 0x888888;
  if (name === "Limestone") col = 0xD3D3B6;
  if (name === "Quartzite") col = 0xE6E6FA;
  if (name === "Granite") col = 0xA9A9A9;
  if (name === "Peat") col = 0x6B4F29;
  if (name === "Ice") col = 0xDAF5FF;
  if (name === "Sandstone") col = 0xE0C68B;
  let mesh = new THREE.Mesh(
    new THREE.DodecahedronGeometry(4 + Math.random() * 2),
    new THREE.MeshPhongMaterial({ color: col })
  );
  mesh.position.set(x, y, z);
  return mesh;
}
function makeAnimal(name, x, y, z) {
  let def = ANIMAL_MODELS[name] || { color: 0x999999, size: 4 };
  let mesh = new THREE.Mesh(
    new THREE.SphereGeometry(def.size, 10, 8),
    new THREE.MeshPhongMaterial({ color: def.color })
  );
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  return { mesh, name, size: def.size, wanderDir: Math.random() * Math.PI * 2, wanderTime: 0 };
}

// --- UI ---
const infoDiv = document.getElementById('biomeInfo');
const hudDiv = document.getElementById('hud');
const centerMsg = document.getElementById('centerMsg');
const invDiv = document.getElementById('inv');
function updateBiomeInfo() {
  const pos = camera.position;
  const biome = getBiomeAt(pos.x, pos.z);
  const elev = getTerrainHeight(pos.x, pos.z);
  const temp = getTemperature(biome, elev, season, timeOfDay);
  infoDiv.innerHTML = `<b>${biome.name} Biome</b><br>
    <b>Day:</b> ${dayCount} <b>Season:</b> ${season}<br>
    <b>Time:</b> ${String(Math.floor(timeOfDay)).padStart(2, "0")}:00<br>
    <b>Elevation:</b> ${Math.round(elev)}m &nbsp; <b>Temp:</b> <span style="color:${temp < 0 ? '#08f' : temp > 30 ? '#e93' : '#080'}">${temp}°C</span><br>
    <b>Trees:</b> ${biome.trees.join(", ") || "-"}<br>
    <b>Rocks:</b> ${biome.rocks.join(", ") || "-"}<br>
    <b>Plants:</b> ${biome.plants.join(", ") || "-"}<br>
    <b>Animals:</b> ${biome.animals.join(", ") || "-"}<br>
    <hr><small>Move, mine rocks/chop trees (<b>E</b>), and survive!</small>`;
}
function updateHUD() {
  hudDiv.innerHTML = `
    <span>❤️ Health: ${player.health.toFixed(0)}</span>
    <span>🍖 Hunger: ${player.hunger.toFixed(0)}</span>
    <span>🌡️ Temp: ${player.temperature.toFixed(1)}°C</span>
  `;
}
function showMsg(msg, ms = 1200) {
  centerMsg.innerHTML = msg;
  centerMsg.style.display = "block";
  setTimeout(() => centerMsg.style.display = "none", ms);
}
function toggleInventory() {
  if (invDiv.style.display === "block") {
    invDiv.style.display = "none";
  } else {
    let inv = "<b>Inventory</b>";
    for (let k in player.inventory)
      inv += `<br>${k}: ${player.inventory[k]}`;
    if (inv === "<b>Inventory</b>") inv += "<br><i>(empty)</i>";
    invDiv.innerHTML = inv;
    invDiv.style.display = "block";
  }
}

// --- Biome/temperature logic ---
function getTemperature(biome, elev, season, time) {
  const s = SEASON_TEMP[season];
  const min = s.min - s.lapse * elev;
  const max = s.max - s.lapse * elev;
  const t = Number(time);
  return (min + (max - min) * (0.5 - 0.5 * Math.cos(Math.PI * t / 12))).toFixed(1);
}

// --- WASD + Jump movement ---
const controls = new THREE.PointerLockControls(camera, document.body);
function setCameraToGround(x, z) {
  const y = getTerrainHeight(x, z) + 4;
  camera.position.set(x, y, z);
}
setCameraToGround(0, 0);

function enableGamePointerLock() {
  controls.lock();
  menuDiv.style.display = "none";
  gameStarted = true;
}
document.getElementById("startGameBtn").onclick = enableGamePointerLock;
document.body.addEventListener('click', () => {
  if (gameStarted && !controls.isLocked) controls.lock();
});
controls.addEventListener('lock', () => document.body.style.cursor = 'none');
controls.addEventListener('unlock', () => {
  document.body.style.cursor = 'default';
  if (gameStarted) menuDiv.style.display = "flex";
});

const move = { forward: 0, back: 0, left: 0, right: 0 };
let velocityY = 0, onGround = true;
document.addEventListener('keydown', e => {
  if (!gameStarted) return;
  if (e.code === 'KeyW') move.forward = 1;
  if (e.code === 'KeyS') move.back = 1;
  if (e.code === 'KeyA') move.left = 1;
  if (e.code === 'KeyD') move.right = 1;
  if (e.code === 'Space' && onGround) { velocityY = 6; onGround = false; }
  if (e.code === 'Tab') { e.preventDefault(); toggleInventory(); }
  if (e.code === 'KeyE') tryInteract();
});
document.addEventListener('keyup', e => {
  if (e.code === 'KeyW') move.forward = 0;
  if (e.code === 'KeyS') move.back = 0;
  if (e.code === 'KeyA') move.left = 0;
  if (e.code === 'KeyD') move.right = 0;
});

// --- Interact: Mine/chop ---
function tryInteract() {
  const pos = camera.position;
  // Nearby rocks
  for (let obj of rocks) {
    if (!obj.mesh.visible) continue;
    if (obj.mesh.position.distanceTo(pos) < 12) {
      obj.mesh.visible = false;
      if (!player.inventory[obj.name]) player.inventory[obj.name] = 0;
      player.inventory[obj.name]++;
      showMsg(`+1 ${obj.name}`);
      updateHUD();
      return;
    }
  }
  // Nearby trees
  for (let obj of trees) {
    if (!obj.mesh.visible) continue;
    if (obj.mesh.position.distanceTo(pos) < 14) {
      obj.mesh.visible = false;
      if (!player.inventory[obj.name]) player.inventory[obj.name] = 0;
      player.inventory[obj.name]++;
      showMsg(`+1 ${obj.name} Wood`);
      updateHUD();
      return;
    }
  }
  // Nearby animals (simple: observe)
  for (let animal of animals) {
    if (!animal.mesh.visible) continue;
    if (animal.mesh.position.distanceTo(pos) < 15) {
      showMsg(`You see a ${animal.name}!`);
      return;
    }
  }
  showMsg("Nothing to interact!", 700);
}

// --- Animal wandering behavior ---
function updateAnimals(dt) {
  for (let animal of animals) {
    if (!animal.mesh.visible) continue;
    animal.wanderTime -= dt;
    let b = getBiomeAt(animal.mesh.position.x, animal.mesh.position.z);
    if (animal.wanderTime <= 0) {
      animal.wanderDir = Math.random() * Math.PI * 2;
      animal.wanderTime = 3 + Math.random() * 4;
    }
    let speed = 3 + Math.random();
    let dx = Math.cos(animal.wanderDir) * speed * dt;
    let dz = Math.sin(animal.wanderDir) * speed * dt;
    let nx = animal.mesh.position.x + dx;
    let nz = animal.mesh.position.z + dz;
    if (nx < b.x[0] + 10 || nx > b.x[1] - 10) animal.wanderDir = Math.PI - animal.wanderDir;
    if (nz < b.z[0] + 10 || nz > b.z[1] - 10) animal.wanderDir = -animal.wanderDir;
    const ny = getTerrainHeight(nx, nz) + animal.size / 2;
    animal.mesh.position.x = nx;
    animal.mesh.position.z = nz;
    animal.mesh.position.y = ny;
  }
}

// --- Game loop ---
function advanceTime(dt) {
  timeOfDay += dt;
  if (timeOfDay >= 24) {
    timeOfDay -= 24;
    dayCount++;
    if ((dayCount - 1) % 5 === 0) {
      const i = (SEASONS.indexOf(season) + 1) % SEASONS.length;
      season = SEASONS[i];
    }
    player.hunger = Math.max(0, player.hunger - 5);
  }
  // Apply temperature effects -- FIX: scale drain by dt!
  const biome = getBiomeAt(camera.position.x, camera.position.z);
  const elev = getTerrainHeight(camera.position.x, camera.position.z);
  const extTemp = getTemperature(biome, elev, season, timeOfDay);
  player.temperature += (extTemp - player.temperature) * 0.04 * dt;
  if (player.temperature < 28 || player.temperature > 41)
    player.health = Math.max(0, player.health - 0.03 * dt); // much slower drain!
  if (player.hunger <= 0)
    player.health = Math.max(0, player.health - 0.04 * dt); // much slower drain!
}

function animate() {
  requestAnimationFrame(animate);

  // --- Calculate real elapsed time since last frame ---
  const now = performance.now();
  const dtReal = (now - lastTime) / 1000;
  lastTime = now;

  if (gameStarted) {
    // --- WASD controls and gravity (scaled by dtReal) ---
    const baseSpeed = 6;
    const moveSpeed = baseSpeed * dtReal;
    if (controls.isLocked) {
      if (move.forward) controls.moveForward(moveSpeed);
      if (move.back) controls.moveForward(-moveSpeed);
      if (move.left) controls.moveRight(-moveSpeed);
      if (move.right) controls.moveRight(moveSpeed);
      velocityY -= 9.8 * dtReal;
      camera.position.y += velocityY * dtReal;
      const ground = getTerrainHeight(camera.position.x, camera.position.z) + 4;
      if (camera.position.y < ground) {
        camera.position.y = ground; velocityY = 0; onGround = true;
      }
      player.position = { x: camera.position.x, y: camera.position.y, z: camera.position.z };
    }

    // --- Advance in-game time based on real time ---
    const dtGame = (24 / SECONDS_PER_DAY) * dtReal;
    advanceTime(dtGame);

    // Day/night sky color
    let t = (timeOfDay / 24);
    let sky = new THREE.Color().lerpColors(new THREE.Color(0x2a375b), new THREE.Color(0xdbefff), Math.sin(t * Math.PI));
    renderer.setClearColor(sky);

    // Sun position
    sun.position.set(200 * Math.sin(timeOfDay / 24 * Math.PI * 2), 150 * Math.sin(timeOfDay / 24 * Math.PI), 0);

    updateAnimals(dtReal);
    updateBiomeInfo();
    updateHUD();

    if (player.health <= 0) {
      showMsg("GAME OVER<br><small>Refresh to restart</small>", 99999);
    }
  }

  renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});