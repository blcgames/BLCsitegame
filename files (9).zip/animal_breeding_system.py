import random

# Species breeding data
SPECIES_DATA = {
    "Red Fox": {
        "breeding_season": "Spring",
        "in_heat_duration": 5,    # ticks
        "breeding_cooldown": 100, # ticks (simulate 1 year)
        "offspring_range": (3, 6),
        "mate_range": 2
    },
    "Moose": {
        "breeding_season": "Autumn",
        "in_heat_duration": 7,
        "breeding_cooldown": 100,
        "offspring_range": (1, 2),
        "mate_range": 3
    },
    "Polar Bear": {
        "breeding_season": "Spring",
        "in_heat_duration": 4,
        "breeding_cooldown": 100,
        "offspring_range": (1, 3),
        "mate_range": 2
    },
    "Penguin": {
        "breeding_season": "Winter",
        "in_heat_duration": 6,
        "breeding_cooldown": 100,
        "offspring_range": (1, 2),
        "mate_range": 2
    },
    # Extend with more animals!
}

class Animal:
    def __init__(self, species, sex, position):
        self.species = species
        self.sex = sex  # "male" or "female"
        self.position = position
        self.is_adult = True
        self.breeding_timer = 0
        self.in_heat = False
        self.in_heat_timer = 0
        self.has_bred_this_year = False

    def update_breeding(self, season):
        data = SPECIES_DATA[self.species]
        if self.sex == "female":
            if not self.in_heat and not self.has_bred_this_year and season == data["breeding_season"]:
                self.breeding_timer += 1
                if self.breeding_timer >= data["breeding_cooldown"]:
                    self.in_heat = True
                    self.in_heat_timer = 0
            if self.in_heat:
                self.in_heat_timer += 1
                if self.in_heat_timer >= data["in_heat_duration"]:
                    self.in_heat = False
                    self.has_bred_this_year = True
                    self.breeding_timer = 0

    def can_breed(self, other, distance):
        data = SPECIES_DATA[self.species]
        return (self.is_adult and other.is_adult and
                self.sex != other.sex and
                self.in_heat and
                distance <= data["mate_range"])

    def reproduce(self):
        data = SPECIES_DATA[self.species]
        n_babies = random.randint(*data["offspring_range"])
        return [Animal(self.species, sex=random.choice(["male", "female"]), position=self.position) for _ in range(n_babies)]