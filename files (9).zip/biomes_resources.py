# Biome resources, diversity, and gameplay impact definitions

BIOMES = {
    "Tundra": {
        "trees": [
            {"name": "Dwarf Birch", "hardness": "low", "color": "white", "fuel": "poor", "uses": ["basic tools", "fuel"]},
        ],
        "rocks": [
            {"name": "Granite", "hardness": "high", "color": "gray", "uses": ["construction", "tools"], "drops": [
                {"item": "Granite", "chance": 1.0},
                {"item": "Metal Ore", "chance": 0.04},
                {"item": "Silver Ore", "chance": 0.01},
                {"item": "Gold Ore", "chance": 0.003},
                {"item": "Diamond", "chance": 0.001},
                {"item": "Emerald", "chance": 0.0005},
                {"item": "Ruby", "chance": 0.0005},
                {"item": "Sapphire", "chance": 0.0005}
            ]},
        ],
        "plants": [
            {"name": "Lichen", "uses": ["medicine", "food"]},
            {"name": "Arctic Moss", "uses": ["medicine", "fuel"]}
        ],
        "animals": ["Snow Rabbit", "White Wolf", "Polar Bear", "Moose", "Penguin"],
        "resource_abundance": {"wood": "scarce", "stone": "plentiful", "metal": "rare", "plants": "scarce"},
        "visual": "tundra_tileset",
        "audio": "windy_arctic"
    },
    "Alpine": {
        "trees": [
            {"name": "Spruce", "hardness": "medium", "color": "dark green", "fuel": "good", "uses": ["building", "fuel"]}
        ],
        "rocks": [
            {"name": "Quartzite", "hardness": "high", "color": "white", "uses": ["building"], "drops": [
                {"item": "Quartzite", "chance": 1.0},
                {"item": "Metal Ore", "chance": 0.12},
                {"item": "Silver Ore", "chance": 0.03},
                {"item": "Gold Ore", "chance": 0.01},
                {"item": "Diamond", "chance": 0.002},
                {"item": "Emerald", "chance": 0.002},
                {"item": "Ruby", "chance": 0.001},
                {"item": "Sapphire", "chance": 0.001}
            ]}
        ],
        "plants": [
            {"name": "Alpine Flower", "uses": ["medicine"]},
            {"name": "Edelweiss", "uses": ["decoration"]}
        ],
        "animals": ["Mountain Goat", "Snow Rabbit", "White Wolf", "Red Fox"],
        "resource_abundance": {"wood": "scarce", "stone": "plentiful", "metal": "moderate", "plants": "moderate"},
        "visual": "alpine_tileset",
        "audio": "windy_mountain"
    },
    # ... (repeat for Forest, Savannah, Desert, Wetlands, Boreal, Polar as in previous examples)
}