// Example integration in your main game loop

import { AnimalBehaviorSystem } from "./AnimalBehaviorSystem";
import { Animal } from "./exampleAnimalObject";

// Assume you have a temperatureSystem instance
const animalBehaviorSystem = new AnimalBehaviorSystem(temperatureSystem);

// Example animals
const animals = [
  new Animal("Snow Rabbit", { x: 100, y: 1200, z: 100 }),
  new Animal("Grey Wolf",   { x: 200, y: 350,  z: 300 }),
  new Animal("White Wolf",  { x: 300, y: 1700, z: 800 }),
  new Animal("Red Fox",     { x: 400, y: 70,   z: 90  }),
  new Animal("Deer",        { x: 500, y: 150,  z: 200 }),
  new Animal("Bear",        { x: 600, y: 400,  z: 300 }),
  new Animal("Chicken",     { x: 700, y: 20,   z: 200 }),
  new Animal("Moose",       { x: 800, y: 800,  z: 500 }),
  new Animal("Reindeer",    { x: 900, y: 1500, z: 600 }),
];

// In your game loop
animals.forEach(animal => {
  animalBehaviorSystem.updateAnimalBehavior(animal);
  // animal.status and position are now updated based on temp comfort!
  // Use status for animations, AI logic, or debug info
});