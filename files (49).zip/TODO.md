# Survival Game — Feature To-Do List

## ✅ DONE (Fully Implemented)

- Main menu (New Game / Load Game)
- Pause menu (P key, resume/save/load [placeholders], sound volume UI, edit controls button)
- Procedural landscape with biomes (forest, plains, desert, snow)
- Day/night cycle (visual light, color, time system)
- 4 seasons, 5 days per season
- Per-biome temperature system (shown on HUD, affected by season & day/night)
- Trees and rocks per biome, generated procedurally as you walk
- Chopping trees and mining rocks (left-click interaction)
- Item drops (logs, rocks) and pickup (E key)
- Inventory and hotbar UI (Tab to open/close, hotbar display)
- Basic HUD (season, day, time, biome, temperature)
- FPS controls (WASD, Shift for run, Ctrl for down, Space for up, mouse look)
- Modular file/code structure, ready for Netlify deployment

---

## ❌ NOT YET IMPLEMENTED

- Animal system:  
  - Spawning, per-biome species  
  - Animal AI (migration, movement, breeding, eating, sleeping)  
  - Drops (meat, eggs, milk, feathers, etc.)  
  - Pets/taming system  
- Eating/drinking system (hunger, thirst, food & water sources, consequences for neglect)
- Crafting system (UI, recipes, item creation)
- Tool/weapon durability and advanced types (hoe, axe, sword, bow, pickaxe, hammer, saw)
- Building system (placing logs, rocks, bricks; physics-based construction)
- Animal migration and temperature/seasonal adaptation
- Procedural rivers, water, rain, weather effects
- Inventory actions:  
  - Drop (G key), drag/drop, stacking logic, item use
- Advanced sound/music, settings, remappable controls
- Saving/loading actual game state (not just placeholder)
- Advanced UI polish and accessibility

---

**You have a solid foundation, but all the major “sandbox survival” systems are still to be built!**

---

## Next Steps

- [ ] Pick which new system to build next (animals, crafting, building, hunger/thirst, etc.)
- [ ] Implement, test, and iterate!
- [ ] Repeat until your game is fully featured

---

*Ask for any feature above, and I’ll generate the code for it next!*