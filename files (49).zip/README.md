# Survival Game (Web)

## How to play locally

1. Copy all files from this repo.
2. Open `index.html` in your browser.

## How to deploy to Netlify

1. Push this folder to a new GitHub repo.
2. Login to [Netlify](https://netlify.com/) and click “New site from Git”.
3. Connect your repo and deploy.
4. Set the publish directory to root (`/`). No build command needed.

---

## Controls

- **WASD** — Move
- **Mouse** — Look around (click game to capture mouse)
- **Shift** — Run
- **Space** — Up
- **Left Ctrl** — Down
- **P** — Pause menu
- **Tab** — Inventory

---

## Features

- Menu (new/load), pause menu (P), settings
- Day/night system
- 4 seasons, 5 days per season
- Per-biome temperature system (season & day/night affects temp)
- Procedural landscape & biomes, always expands as you walk
- Trees and rocks per biome, can be chopped/mined
- Pickup drops, inventory & hotbar (Tab to open)
- Basic HUD (season, day/time, biome, temp)

---

## Next Steps

- Add animal spawning, crafting, tool durability, building, and advanced systems as desired.

PRs/issues welcome!