import * as THREE from 'https://unpkg.com/three@0.153.0/build/three.module.js';
import { addItemToInventory, removeItemFromInventory, inventory, hotbar, selected } from './inventory.js';

export let buildMode = false;
export let buildMaterial = null; // { id, color }

const BUILD_MATERIALS = {
  log: { color: 0xa0522d, name: "Log" },
  rock: { color: 0x888888, name: "Rock" },
  wood: { color: 0xdeb887, name: "Wood" },
  brick: { color: 0xb22222, name: "Brick" }
};

let placedBlocks = [];

export function getBuildableMaterials() {
  // From inventory, only those with count > 0 and are in BUILD_MATERIALS
  return inventory.filter(item => BUILD_MATERIALS[item.id] && item.count > 0);
}

export function startBuildMode() {
  buildMode = true;
  // Default to first buildable material in hotbar
  const mat = getBuildableMaterials()[0];
  setBuildMaterial(mat ? mat.id : null);
  document.body.classList.add('build-mode');
}

export function stopBuildMode() {
  buildMode = false;
  buildMaterial = null;
  document.body.classList.remove('build-mode');
}

export function setBuildMaterial(id) {
  if (!id || !BUILD_MATERIALS[id]) {
    buildMaterial = null;
    return;
  }
  buildMaterial = { id, ...BUILD_MATERIALS[id] };
}

export function handleBuildClick(raycaster, scene, cam, action = 'place') {
  if (!buildMode || !buildMaterial) return;
  if (action === 'place') {
    // Place block in front of player, on ground or on another block
    const distance = 3;
    const dir = new THREE.Vector3();
    cam.getWorldDirection(dir);
    const placePos = cam.position.clone().add(dir.multiplyScalar(distance));
    placePos.y = Math.round(placePos.y);
    placePos.x = Math.round(placePos.x);
    placePos.z = Math.round(placePos.z);

    // Check if there's a block or ground at/under this position
    let canPlace = false;
    // Raycast down from intended pos to find ground/other block
    const down = new THREE.Vector3(0, -1, 0);
    const testRay = new THREE.Raycaster(placePos, down, 0, 2);
    const intersects = testRay.intersectObjects(placedBlocks, false);
    if (placePos.y <= 0.5 || intersects.length > 0) canPlace = true;
    if (!canPlace) return;

    // Remove material from inventory
    if (!removeItemFromInventory(buildMaterial.id, 1)) return;

    // Place visual block
    const mesh = new THREE.Mesh(
      new THREE.BoxGeometry(1, 1, 1),
      new THREE.MeshLambertMaterial({ color: buildMaterial.color })
    );
    mesh.position.set(placePos.x, placePos.y, placePos.z);
    mesh.userData = { type: 'build', material: buildMaterial.id };
    scene.add(mesh);
    placedBlocks.push(mesh);
  }
  if (action === 'remove') {
    // Remove block on click if close and tool matches
    const intersects = raycaster.intersectObjects(placedBlocks, false);
    if (intersects.length > 0) {
      const mesh = intersects[0].object;
      // Only remove if they have correct tool
      const mat = mesh.userData.material;
      const toolNeeded =
        mat === 'log' || mat === 'wood' ? 'axe' :
        mat === 'rock' || mat === 'brick' ? 'pickaxe' : null;
      if (!hasTool(toolNeeded)) return;
      scene.remove(mesh);
      placedBlocks.splice(placedBlocks.indexOf(mesh), 1);
      addItemToInventory(mat, 1);
    }
  }
}

function hasTool(toolId) {
  if (!toolId) return true;
  return inventory.some(i => i.id === toolId && i.count > 0);
}

export function renderBuildHUD() {
  if (!buildMode) return;
  let el = document.getElementById('build-hud');
  if (!el) {
    el = document.createElement('div');
    el.id = 'build-hud';
    el.style.position = 'fixed';
    el.style.top = '0';
    el.style.left = '45vw';
    el.style.background = '#222c';
    el.style.color = '#fff';
    el.style.padding = '8px 20px';
    el.style.borderRadius = '0 0 8px 8px';
    el.style.zIndex = '1000';
    document.body.appendChild(el);
  }
  el.innerHTML = `<b>BUILD MODE:</b> ${buildMaterial ? buildMaterial.name : '(no material selected)'}
    <br>Scroll to change material, Left click: Place | Right click: Remove | B: Exit`;
  el.style.display = 'block';
}