// Save and load game state from localStorage
import { inventory, hotbar, selected } from './inventory.js';
import { buildMode, buildMaterial } from './building.js';
// Import more as needed: player pos, hunger, thirst, health, time, season, day, placed blocks, animals, etc.

export function saveGame(state) {
  try {
    localStorage.setItem('survival_save', JSON.stringify(state));
    return true;
  } catch (e) {
    alert("Failed to save game: " + e);
    return false;
  }
}

export function loadGame() {
  try {
    const raw = localStorage.getItem('survival_save');
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}