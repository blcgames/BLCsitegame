// Simple sound system using HTML5 Audio

const SOUNDS = {
  chop: 'sounds/chop.mp3',
  mine: 'sounds/mine.mp3',
  eat: 'sounds/eat.mp3',
  drink: 'sounds/drink.mp3',
  animal: 'sounds/animal.mp3',
  rain: 'sounds/rain.mp3',
  place: 'sounds/place.mp3',
  break: 'sounds/break.mp3',
  music: 'sounds/music.mp3'
};

let sfxVolume = 0.9;
let musicVolume = 0.7;
let musicAudio = null;
let musicEnabled = true;
let sfxEnabled = true;

export function playSound(name) {
  if (!sfxEnabled || !SOUNDS[name]) return;
  const audio = new Audio(SOUNDS[name]);
  audio.volume = sfxVolume;
  audio.play();
}

export function playMusic() {
  if (!musicEnabled) return;
  if (!SOUNDS.music) return;
  if (musicAudio) { musicAudio.pause(); musicAudio = null; }
  musicAudio = new Audio(SOUNDS.music);
  musicAudio.loop = true;
  musicAudio.volume = musicVolume;
  musicAudio.play();
}
export function stopMusic() {
  if (musicAudio) musicAudio.pause();
  musicAudio = null;
}

export function setSFXVolume(val) { sfxVolume = val; }
export function setMusicVolume(val) { musicVolume = val; if (musicAudio) musicAudio.volume = val; }
export function enableMusic(val) { musicEnabled = val; if (val) playMusic(); else stopMusic(); }
export function enableSFX(val) { sfxEnabled = val; }