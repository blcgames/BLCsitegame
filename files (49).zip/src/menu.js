export function showMainMenu({ onNew, onLoad }) {
  const menu = document.getElementById('menu');
  menu.innerHTML = `
    <h1>Survival Game</h1>
    <button id="newGame">New Game</button>
    <button id="loadGame">Load Game</button>
  `;
  menu.style.display = 'flex';
  document.getElementById('newGame').onclick = onNew;
  document.getElementById('loadGame').onclick = onLoad;
}

export function showPauseMenu({ onResume, onSave, onLoad }) {
  const menu = document.getElementById('pauseMenu');
  menu.innerHTML = `
    <h2>Paused</h2>
    <button id="resume">Resume</button>
    <button id="save">Save Game</button>
    <button id="load">Load Game</button>
    <hr/>
    <label>Sound: <input id="volume" type="range" min="0" max="100" value="50"></label>
    <button id="editControls">Edit Controls</button>
  `;
  menu.style.display = 'flex';
  document.getElementById('resume').onclick = onResume;
  document.getElementById('save').onclick = onSave;
  document.getElementById('load').onclick = onLoad;
  // TODO: Wire up volume and edit controls
}

export function hidePauseMenu() {
  document.getElementById('pauseMenu').style.display = 'none';
}