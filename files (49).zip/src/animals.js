import * as THREE from 'https://unpkg.com/three@0.153.0/build/three.module.js';
import { getBiomeAt } from './worldgen.js';
import { addItemToInventory } from './inventory.js';

const ANIMAL_TYPES = [
  { type: "rabbit", biomes: ["plains", "forest"], color: 0xffffff, drops: { meat: 1 }, tameable: false, speed: 0.05 },
  { type: "wolf", biomes: ["forest", "snow"], color: 0x888888, drops: { meat: 2 }, tameable: true, speed: 0.07 },
  { type: "sheep", biomes: ["plains"], color: 0xeeeeee, drops: { meat: 2, wool: 1 }, tameable: true, speed: 0.04 },
  { type: "chicken", biomes: ["plains", "forest"], color: 0xffff88, drops: { meat: 1, egg: 1 }, tameable: false, speed: 0.06 },
  { type: "cow", biomes: ["plains"], color: 0x333333, drops: { meat: 3, milk: 1 }, tameable: true, speed: 0.03 },
  { type: "penguin", biomes: ["snow"], color: 0x223344, drops: { meat: 1, feather: 1 }, tameable: false, speed: 0.05 }
];

let animals = [];

export function updateAnimals(scene, time, seasonIdx, day) {
  // Animal spawn logic: keep 2-4 animals per biome patch around player
  const playerPos = scene.children.find(o => o.isPerspectiveCamera)?.position || { x: 0, z: 0 };
  const spawnRadius = 40;
  ANIMAL_TYPES.forEach(animalType => {
    // For each biome in view, check animal count
    animalType.biomes.forEach(biome => {
      let count = animals.filter(
        a => a.userData.type === animalType.type && a.userData.biome === biome &&
          a.position.distanceTo(playerPos) < spawnRadius
      ).length;
      if (count < 2) {
        // Spawn new animal
        const x = playerPos.x + Math.random() * spawnRadius * 2 - spawnRadius;
        const z = playerPos.z + Math.random() * spawnRadius * 2 - spawnRadius;
        if (getBiomeAt(x, z) !== biome) return;
        const mesh = new THREE.Mesh(
          new THREE.SphereGeometry(0.5, 8, 8),
          new THREE.MeshLambertMaterial({ color: animalType.color })
        );
        mesh.position.set(x, 0.5, z);
        mesh.userData = {
          type: animalType.type,
          biome,
          health: 2 + Math.floor(Math.random() * 2),
          tamed: false
        };
        scene.add(mesh);
        animals.push(mesh);
      }
    });
  });

  // Remove far animals
  animals = animals.filter(animal => {
    if (animal.position.distanceTo(playerPos) > spawnRadius * 2) {
      scene.remove(animal);
      return false;
    }
    return true;
  });

  // Simple random walk for untamed animals
  animals.forEach((animal, idx) => {
    if (!animal.userData.tamed) {
      const typeData = ANIMAL_TYPES.find(t => t.type === animal.userData.type);
      animal.position.x += (Math.random() - 0.5) * typeData.speed;
      animal.position.z += (Math.random() - 0.5) * typeData.speed;
    }
    // Animate
    animal.position.y = 0.5 + Math.sin(time * 2 + idx) * 0.05;
  });
}

// Raycast interaction for animals: hunt (left click) or tame (shift+click)
export function tryAnimalInteract(raycaster, scene, mode = "hunt") {
  const intersects = raycaster.intersectObjects(animals, false);
  if (intersects.length === 0) return;
  const mesh = intersects[0].object;
  const typeData = ANIMAL_TYPES.find(t => t.type === mesh.userData.type);
  if (mode === "tame" && typeData.tameable && !mesh.userData.tamed) {
    mesh.userData.tamed = true;
    mesh.material.color.set(0x00ff00);
    // Optional: add to pets
  } else if (mode === "hunt") {
    mesh.userData.health -= 1;
    if (mesh.userData.health <= 0) {
      // Drop items
      for (const [id, count] of Object.entries(typeData.drops)) {
        addItemToInventory(id, count);
      }
      scene.remove(mesh);
      animals.splice(animals.indexOf(mesh), 1);
    }
  }
}