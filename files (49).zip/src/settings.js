import { setSFXVolume, setMusicVolume, enableMusic, enableSFX, playMusic, stopMusic } from './sound.js';

let controls = {
  moveForward: 'KeyW',
  moveBackward: 'KeyS',
  moveLeft: 'KeyA',
  moveRight: 'KeyD',
  jump: 'Space',
  interact: 'Mouse0',
  inventory: 'Tab',
  build: 'KeyB',
  eat: 'Digit1',
  drink: 'Digit2',
  craft: 'KeyC'
};

export function showSettings() {
  let el = document.getElementById('settings');
  if (!el) {
    el = document.createElement('div');
    el.id = 'settings';
    el.className = 'settings';
    document.body.appendChild(el);
  }
  el.innerHTML = `
    <h3>Settings</h3>
    <label>SFX Volume: <input type="range" min="0" max="1" step="0.01" value="0.9" oninput="window._setSFXVolume(this.value)"></label><br>
    <label>Music Volume: <input type="range" min="0" max="1" step="0.01" value="0.7" oninput="window._setMusicVolume(this.value)"></label><br>
    <label><input type="checkbox" checked onchange="window._enableMusic(this.checked)"> Music</label>
    <label><input type="checkbox" checked onchange="window._enableSFX(this.checked)"> Sound FX</label>
    <br>
    <b>Remap Controls:</b>
    <div id="remap-controls">
      ${
        Object.entries(controls).map(([act,key])=>`
          <div>
            ${act}: <button onclick="window._remapControl('${act}')">${key}</button>
          </div>
        `).join('')
      }
    </div>
    <button onclick="window._closeSettings()">Close</button>
  `;
  el.style.display = 'block';

  window._setSFXVolume = setSFXVolume;
  window._setMusicVolume = setMusicVolume;
  window._enableMusic = enableMusic;
  window._enableSFX = enableSFX;
  window._closeSettings = () => { el.style.display = 'none'; };
  window._remapControl = promptRemap;
}

function promptRemap(act) {
  alert(`Press a key or mouse button for: ${act}`);
  window.addEventListener('keydown', function handler(e) {
    controls[act] = e.code;
    showSettings();
    window.removeEventListener('keydown', handler, true);
  }, true);
}
export function getControlKey(act) {
  return controls[act];
}