let inventory = [
  { id: 'axe', name: 'Axe', count: 1, type: 'tool', durability: 30, maxDurability: 30 },
  { id: 'pickaxe', name: 'Pickaxe', count: 0, type: 'tool', durability: 30, maxDurability: 30 },
  { id: 'sword', name: 'Sword', count: 0, type: 'weapon', durability: 25, maxDurability: 25 },
  { id: 'meat', name: 'Meat', count: 2, type: 'food', value: 30 },
  { id: 'rock', name: 'Rock', count: 4, type: 'material' },
  { id: 'egg', name: 'Egg', count: 0, type: 'food', value: 10 },
  { id: 'milk', name: 'Milk', count: 0, type: 'drink', value: 20 },
  { id: 'wool', name: 'Wool', count: 0, type: 'material' },
  { id: 'feather', name: 'Feather', count: 0, type: 'material' },
  { id: 'water', name: 'Water', count: 0, type: 'drink', value: 25 },
  { id: 'wood', name: 'Wood', count: 0, type: 'material' },
  { id: 'cooked_meat', name: 'Cooked Meat', count: 0, type: 'food', value: 50 }
];
let hotbar = [0, 1, 2, 3, 4];
let selected = 0;
let invOpen = false;
let draggingSlot = null;
let dragSource = null;

// ... RECIPES definition (as before, omitted for brevity) ...

export function showInventory() {
  let inv = document.getElementById('inventory');
  if (!inv) {
    inv = document.createElement('div');
    inv.id = 'inventory';
    inv.className = 'inventory';
    document.body.appendChild(inv);
  }
  // Crafting UI
  let craftList = RECIPES.map(r => {
    const canCraft = r.ingredients.every(ing => getItemCount(ing.id) >= ing.count);
    return `<div>
      <b>${r.name}</b> 
      <small>${r.ingredients.map(ing => `${ing.count} ${getItemName(ing.id)}`).join(', ')}</small>
      <button onclick="window._craftItem('${r.id}')" ${canCraft ? '' : 'disabled'}>Craft</button>
    </div>`;
  }).join('');

  // Inventory grid with drag and drop
  let invGrid = inventory.map((item, i) => `
    <span class="inventory-slot" draggable="true" 
      ondragstart="window._dragInv(event,${i})" 
      ondragover="window._dragOverInv(event,${i})" 
      ondrop="window._dropInv(event,${i})"
      onclick="window._useInvItem(${i})"
      >
      ${item.name}<br>${item.count}
      ${item.durability ? `<br><small>${item.durability}/${item.maxDurability}</small>` : ""}
    </span>
  `).join('');

  // Hotbar
  let hotbarHTML = hotbar.map((idx, i) => `
    <span class="inventory-slot hotbar${i===selected?' selected':''}"
      draggable="true"
      ondragstart="window._dragHotbar(event,${i})"
      ondragover="window._dragOverHotbar(event,${i})"
      ondrop="window._dropHotbar(event,${i})">
      ${idx>=0?inventory[idx].name+'<br>'+inventory[idx].count+
        (inventory[idx].durability?`<br><small>${inventory[idx].durability}/${inventory[idx].maxDurability}</small>`:'')
      :''}
    </span>
  `).join('');

  inv.innerHTML = `
    <div class="hotbar">${hotbarHTML}</div>
    <div style="margin:4px 0 12px 0;">${invGrid}</div>
    <hr/>
    <div><b>Crafting</b></div>
    <div>${craftList}</div>
    <div><small>Press <b>1-5</b> for hotbar use, <b>G</b> to drop selected, Tab to close. Drag to rearrange.</small></div>
  `;
  inv.style.display = 'block';
  invOpen = true;

  // Drag & drop handlers
  window._dragInv = (e,i) => { draggingSlot = i; dragSource = 'inv'; };
  window._dragOverInv = e => { e.preventDefault(); };
  window._dropInv = (e,i) => {
    e.preventDefault();
    if (dragSource === 'inv' && draggingSlot !== null && draggingSlot !== i) {
      swapInventorySlots(draggingSlot, i);
    } else if (dragSource === 'hotbar' && draggingSlot !== null) {
      // Move from hotbar to inventory position
      let invIdx = hotbar[draggingSlot];
      if (invIdx >= 0) swapInventorySlots(invIdx, i);
    }
    draggingSlot = null; dragSource = null; showInventory();
  };
  window._dragHotbar = (e,i) => { draggingSlot = i; dragSource = 'hotbar'; };
  window._dragOverHotbar = e => { e.preventDefault(); };
  window._dropHotbar = (e,i) => {
    e.preventDefault();
    if (dragSource === 'hotbar' && draggingSlot !== null && draggingSlot !== i) {
      [hotbar[draggingSlot],hotbar[i]] = [hotbar[i],hotbar[draggingSlot]];
    } else if (dragSource === 'inv' && draggingSlot !== null) {
      hotbar[i] = draggingSlot;
    }
    draggingSlot = null; dragSource = null; showInventory();
  };

  // Use item from inventory with click
  window._useInvItem = i => {
    useInvItem(i);
    showInventory(); // update view after use
  };

  window._craftItem = craftItem;
}

export function hideInventory() {
  let inv = document.getElementById('inventory');
  if (inv) inv.style.display = 'none';
  invOpen = false;
}

export function inventoryIsOpen() { return invOpen; }

export function updateInventory() {}

function swapInventorySlots(i1, i2) {
  [inventory[i1], inventory[i2]] = [inventory[i2], inventory[i1]];
  // update hotbar indexes if needed
  hotbar.forEach((idx, n) => {
    if (idx === i1) hotbar[n] = i2;
    else if (idx === i2) hotbar[n] = i1;
  });
}

// Stacking
export function addItemToInventory(itemId, amount) {
  let entry = inventory.find(i => i.id === itemId);
  if (entry) {
    entry.count += amount;
  } else {
    // Guess type
    let type = 'material', value = 0, durability, maxDurability;
    if (itemId === 'meat' || itemId === 'egg') { type = 'food'; value = itemId === 'meat' ? 30 : 10; }
    if (itemId === 'milk' || itemId === 'water') { type = 'drink'; value = itemId === 'milk' ? 20 : 25; }
    if (itemId === 'axe' || itemId === 'pickaxe') { type = 'tool'; durability = 30; maxDurability = 30; }
    if (itemId === 'sword') { type = 'weapon'; durability = 25; maxDurability = 25; }
    if (itemId === 'cooked_meat') { type = 'food'; value = 50; }
    entry = { id: itemId, name: getItemName(itemId), count: amount, type, value, durability, maxDurability };
    inventory.push(entry);
    for (let i = 0; i < hotbar.length; i++) {
      if (hotbar[i] === -1) {
        hotbar[i] = inventory.length - 1;
        break;
      }
    }
  }
}

export function removeItemFromInventory(itemId, amount) {
  let entry = inventory.find(i => i.id === itemId);
  if (!entry || entry.count < amount) return false;
  entry.count -= amount;
  if (entry.count <= 0) {
    let idx = inventory.indexOf(entry);
    inventory.splice(idx, 1);
    // Remove from hotbar if present
    hotbar.forEach((v, n) => { if (v === idx) hotbar[n] = -1; });
  }
  return true;
}

export function useItemFromInventory(hotbarIdx, usage = null) {
  const idx = hotbar[hotbarIdx];
  if (typeof idx !== 'number' || idx < 0) return null;
  return useInvItem(idx, usage);
}
function useInvItem(idx, usage = null) {
  const item = inventory[idx];
  if (!item || item.count < 1) return null;
  if (item.type === 'food' || item.type === 'drink' || item.type === 'heal') {
    item.count--;
    return { type: item.type, value: item.value };
  }
  if ((item.type === 'tool' || item.type === 'weapon') && usage === 'action') {
    if (item.durability) {
      item.durability--;
      if (item.durability <= 0) {
        item.count--;
        item.durability = item.maxDurability;
        if (item.count <= 0) {
          inventory.splice(idx, 1);
          // Remove from hotbar if empty
          for (let i=0; i<hotbar.length; ++i)
            if (hotbar[i] === idx) hotbar[i] = -1;
        }
      }
    }
    return { type: item.type, toolId: item.id };
  }
  return null;
}

function getItemCount(itemId) {
  const entry = inventory.find(i => i.id === itemId);
  return entry ? entry.count : 0;
}

function getItemName(itemId) {
  const entry = inventory.find(i => i.id === itemId);
  if (entry) return entry.name;
  // fallback for crafting UI
  if (itemId === 'wood') return 'Wood';
  if (itemId === 'rock') return 'Rock';
  if (itemId === 'meat') return 'Meat';
  if (itemId === 'axe') return 'Axe';
  if (itemId === 'pickaxe') return 'Pickaxe';
  if (itemId === 'cooked_meat') return 'Cooked Meat';
  if (itemId === 'sword') return 'Sword';
  return itemId.charAt(0).toUpperCase() + itemId.slice(1);
}

// Drop
export function dropHotbarItem(idx, spawnDrop) {
  const invIdx = hotbar[idx];
  if (typeof invIdx !== 'number' || invIdx < 0) return;
  const item = inventory[invIdx];
  if (!item || item.count < 1) return;
  // Remove one from stack
  item.count--;
  if (item.count <= 0) {
    inventory.splice(invIdx, 1);
    hotbar[idx] = -1;
  }
  // Call world.js to spawn the drop
  if (spawnDrop) spawnDrop(item.id, undefined, undefined);
}

// Drag/drop and use from inventory
export function dropInvItem(idx, spawnDrop) {
  if (!inventory[idx] || inventory[idx].count < 1) return;
  inventory[idx].count--;
  if (inventory[idx].count <= 0) inventory.splice(idx, 1);
  if (spawnDrop) spawnDrop(inventory[idx]?.id, undefined, undefined);
}

// Crafting as before...