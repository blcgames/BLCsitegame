let lastWarn = { hunger: false, thirst: false };

export function updateHUD({ time, day, season, biome, temp, hunger, thirst, health }) {
  const hud = document.getElementById('hud');
  hud.innerHTML = `
    <div>Season: <b>${['spring','summer','autumn','winter'][season]}</b> | Day: <b>${day+1}</b></div>
    <div>Time: <b>${formatTime(time)}</b> | Biome: <b>${biome}</b> | Temp: <b>${temp}&deg;C</b></div>
    <div>
      <span>❤️ ${Math.round(health)} </span>
      <span>🍗 Hunger: <b>${Math.round(hunger)}</b></span>
      <span>💧 Thirst: <b>${Math.round(thirst)}</b></span>
    </div>
    <div>Press <b>P</b> to pause, <b>Tab</b> for inventory</div>
    ${
      hunger < 20 ? `<div style="color:#ff3333"><b>Warning: Starving!</b></div>` : ""
    }
    ${
      thirst < 20 ? `<div style="color:#3399ff"><b>Warning: Dehydrated!</b></div>` : ""
    }
  `;
}

function formatTime(t) {
  const mins = Math.floor(t / 60);
  const secs = Math.floor(t % 60);
  return `${mins}:${secs.toString().padStart(2,'0')}`;
}