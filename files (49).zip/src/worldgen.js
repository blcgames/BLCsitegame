export function isRiver(x, z) {
  // Simple sine-wave river every 60 units
  return Math.abs(Math.sin(x / 60) * 40 - z) < 2;
}