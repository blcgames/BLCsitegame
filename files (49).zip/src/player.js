import * as THREE from 'https://unpkg.com/three@0.153.0/build/three.module.js';

let camera, domElement;
let move = { forward: false, backward: false, left: false, right: false, shift: false, ctrl: false, up: false };
let isLocked = false;

let pos = new THREE.Vector3(0, 2, 0);

export function setupPlayerControls(cam, dom) {
  camera = cam;
  domElement = dom;
  camera.position.copy(pos);

  domElement.onclick = () => domElement.requestPointerLock();
  document.addEventListener('pointerlockchange', () => {
    isLocked = document.pointerLockElement === domElement;
  });

  document.addEventListener('mousemove', (e) => {
    if (!isLocked) return;
    camera.rotation.y -= e.movementX * 0.002;
    camera.rotation.x -= e.movementY * 0.002;
    camera.rotation.x = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, camera.rotation.x));
  });

  document.addEventListener('keydown', (e) => {
    switch (e.code) {
      case 'KeyW': move.forward = true; break;
      case 'KeyS': move.backward = true; break;
      case 'KeyA': move.left = true; break;
      case 'KeyD': move.right = true; break;
      case 'ShiftLeft': move.shift = true; break;
      case 'ControlLeft': move.ctrl = true; break;
      case 'Space': move.up = true; break;
    }
  });
  document.addEventListener('keyup', (e) => {
    switch (e.code) {
      case 'KeyW': move.forward = false; break;
      case 'KeyS': move.backward = false; break;
      case 'KeyA': move.left = false; break;
      case 'KeyD': move.right = false; break;
      case 'ShiftLeft': move.shift = false; break;
      case 'ControlLeft': move.ctrl = false; break;
      case 'Space': move.up = false; break;
    }
  });
}

export function updatePlayer() {
  if (!camera) return;
  let speed = move.shift ? 0.2 : 0.08;
  let direction = new THREE.Vector3();
  if (move.forward) direction.z -= 1;
  if (move.backward) direction.z += 1;
  if (move.left) direction.x -= 1;
  if (move.right) direction.x += 1;
  direction.normalize();
  camera.position.x += Math.sin(camera.rotation.y) * direction.z * speed + Math.cos(camera.rotation.y) * direction.x * speed;
  camera.position.z += Math.cos(camera.rotation.y) * direction.z * speed - Math.sin(camera.rotation.y) * direction.x * speed;
  if (move.up) camera.position.y += 0.1;
  if (move.ctrl) camera.position.y -= 0.1;
  pos.copy(camera.position);
}

export function getPlayerPos() {
  return pos.clone();
}

export function setPlayerPos(newpos) {
  pos.copy(newpos);
  if (camera) camera.position.copy(newpos);
}

export function getCamera() {
  return camera;
}