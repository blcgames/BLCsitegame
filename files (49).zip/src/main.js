import { showMainMenu, showPauseMenu, hidePauseMenu } from './menu.js';
import { startGame, loadGame, pauseGame, resumeGame, isPaused } from './world.js';
import { showInventory, hideInventory, inventoryIsOpen } from './inventory.js';

window.onload = () => {
  showMainMenu({
    onNew: () => {
      document.getElementById('menu').style.display = 'none';
      startGame();
    },
    onLoad: () => {
      document.getElementById('menu').style.display = 'none';
      loadGame();
    }
  });

  // Listen for pause key ("P"), Inventory ("Tab")
  document.addEventListener('keydown', e => {
    if (e.code === 'KeyP') {
      if (!isPaused()) {
        pauseGame();
        showPauseMenu({
          onResume: () => { hidePauseMenu(); resumeGame(); },
          onSave: () => {/* TODO */},
          onLoad: () => { /* TODO: loadGame(); */ },
        });
      } else {
        hidePauseMenu();
        resumeGame();
      }
    }
    if (e.code === 'Tab') {
      e.preventDefault();
      if (!inventoryIsOpen()) {
        showInventory();
      } else {
        hideInventory();
      }
    }
  });
};