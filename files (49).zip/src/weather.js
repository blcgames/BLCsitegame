import * as THREE from 'https://unpkg.com/three@0.153.0/build/three.module.js';

const WEATHER_TYPES = ['clear', 'rain', 'snow'];
let currentWeather = 'clear';
let weatherTimer = 0;
let rainParticles = [];
let snowParticles = [];
let effectGroup = null;

export function getCurrentWeather(biome) {
  // In snowy biomes, prefer snow
  if (currentWeather === 'rain' && biome === 'snow') return 'snow';
  if (currentWeather === 'snow' && biome !== 'snow') return 'rain';
  return currentWeather;
}

export function updateWeather(scene, time, season, day, playerBiome) {
  weatherTimer -= 1 / 60; // About once per minute
  if (weatherTimer < 0) {
    // New weather! Desert: rare rain, snow biomes: favor snow
    let roll = Math.random();
    if (playerBiome === 'desert') {
      currentWeather = roll < 0.9 ? 'clear' : 'rain';
    } else if (playerBiome === 'snow') {
      currentWeather = roll < 0.6 ? 'snow' : (roll < 0.8 ? 'rain' : 'clear');
    } else {
      currentWeather = roll < 0.6 ? 'clear' : (roll < 0.85 ? 'rain' : 'snow');
    }
    weatherTimer = 60 + Math.random() * 60; // 1-2 minutes per weather state
  }
  // Remove old effect group
  if (effectGroup) scene.remove(effectGroup);
  effectGroup = new THREE.Group();

  // Add rain or snow particles if needed
  if (getCurrentWeather(playerBiome) === 'rain') {
    rainParticles = [];
    for (let i = 0; i < 120; i++) {
      const geo = new THREE.CylinderGeometry(0.02, 0.02, 0.6, 3);
      const mat = new THREE.MeshLambertMaterial({ color: 0x3366ff });
      const drop = new THREE.Mesh(geo, mat);
      drop.position.set(
        (Math.random() - 0.5) * 20,
        4 + Math.random() * 3,
        (Math.random() - 0.5) * 20
      );
      effectGroup.add(drop);
      rainParticles.push(drop);
    }
    scene.add(effectGroup);
  } else if (getCurrentWeather(playerBiome) === 'snow') {
    snowParticles = [];
    for (let i = 0; i < 100; i++) {
      const geo = new THREE.SphereGeometry(0.06, 4, 4);
      const mat = new THREE.MeshLambertMaterial({ color: 0xffffff });
      const flake = new THREE.Mesh(geo, mat);
      flake.position.set(
        (Math.random() - 0.5) * 20,
        4 + Math.random() * 3,
        (Math.random() - 0.5) * 20
      );
      effectGroup.add(flake);
      snowParticles.push(flake);
    }
    scene.add(effectGroup);
  }
}

export function animateWeather(playerPos, playerBiome) {
  // Animate rain/snow particles above player
  if (effectGroup) {
    effectGroup.position.set(playerPos.x, 0, playerPos.z);
    if (getCurrentWeather(playerBiome) === 'rain') {
      rainParticles.forEach(drop => {
        drop.position.y -= 0.2 + Math.random() * 0.18;
        if (drop.position.y < 0) drop.position.y = 4 + Math.random() * 3;
      });
    } else if (getCurrentWeather(playerBiome) === 'snow') {
      snowParticles.forEach(flake => {
        flake.position.y -= 0.07 + Math.random() * 0.09;
        flake.position.x += (Math.random() - 0.5) * 0.04;
        if (flake.position.y < 0) flake.position.y = 4 + Math.random() * 3;
      });
    }
  }
}

export function isRaining(biome) {
  return getCurrentWeather(biome) === 'rain';
}

export function isSnowing(biome) {
  return getCurrentWeather(biome) === 'snow';
}